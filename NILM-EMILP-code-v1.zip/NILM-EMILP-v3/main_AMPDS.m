%AMPDS:{ 'RSE',	'GRE',	'MHE',	'B1E'	,'BME'	,'CWE',	'DWE','EQE','FRE',	'HPE',	'OFE',	'UTE',	'WOE',	'B2E',	'CDE',	'DNE',	'EBE',	'FGE',	'HTE',	'OUE',	'TVE',	'UNE'}
%AMPDS_alwaysOn:[1,0,1,0,0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0,1,1]
%AMPDS_Appliance_State_num=[3,3,3,3,2,3,2,3,3,2,4,3,2,2,2,3,0,3,3,3,2,5];

clear all;
disp('---------------------------------��ʼ---------------------------');
% FilePath=input('���������ļ�·����');
% solverName=input('ѡ���������CPLEX��GURIOBI����');
% timelimit=input('��������ʱ�����ޣ���λΪ�룩��');
% disp('�������');
% disp('��ʼ��ģ');

data_Folder_Path='data\';
data_Set={'AMPDS','UKDALE','REFIT'};
data_type={'active power','reactive power'};

select_data_Set={'AMPDS'};
select_data_type={'P','Q'};% P is active power  Q is reactive power
select_appliance_name={'CDE','FRE','DWE','HPE' ,'BME','TVE','CWE'}; %,'FRE','DWE','HPE' ,'BME','TVE','CWE' ,'OFE' 20��û�п���,,
   
%{'CDE', 'FRE', 'DWE', 'HPE'};

AMPDS_S=[3,3,3,3,3,2,3,2,3,2,2,4,2,2,2,2,3,0,3,3,3,2,5];
AMPDS_alwaysOn=[1,1,0,1,0,0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0,1,1];
BQP_result=[];
OLDA_result=[];
EMILP_result=[];
CMILP_result=[];
NSAC=[];
train_day_num=20;
test_day_num=1;
train_data_num=60*24*train_day_num;
TIME=10000;
partition_num=1;
result_path=strcat('result/AMPDS/result_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_snr','.txt');
partition_index=1;

SO_result=[];
CO_state=[];
SO_state=[];
OLDA_state=[];
ALIP_state=[];
BQP_state=[];
EMILP_state=[];
CMILP_state=[];
origin_cluster=[];
CO_power=[];
SO_power=[];
OLDA_power=[];
ALIP_power=[];
BQP_power=[];
EMILP_power=[];
CMILP_power=[];
Total_P=[];
disp('��ģ��...');

%  for snr=35:-5:10
    for partition_index=1:7
%         result_path=strcat('result/AMPDS/result_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_snr',num2str(snr),'.txt');

    test_data_num=60*24*(test_day_num/partition_num);
train_data_start_location = 1; % ѵ������������ʼ��
test_data_start_location = (train_data_num+test_data_num*(partition_index-1)+1)*ones(length(select_appliance_name),1);%[31200; 4500; 5700; 14000];


[Total_data,train_data,test_data,appliance_location] = function_read_data(data_Folder_Path,select_data_Set,select_data_type,select_appliance_name,...
    train_data_num,test_data_num,train_data_start_location,test_data_start_location);
% for i=1:size(train_data.AMPDS.appliance_P,2)
%     train_data_noise.AMPDS.appliance_P(:,i) = awgn(train_data.AMPDS.appliance_P(:,i),snr,'measured');
%     train_data_noise.AMPDS.appliance_Q(:,i) = awgn(train_data.AMPDS.appliance_Q(:,i),snr,'measured');
% %     test_data_noise.AMPDS.appliance_P(:,i)=awgn(test_data.AMPDS.appliance_P(:,i),snr,'measured');
% %     test_data_noise.AMPDS.appliance_Q(:,i)=awgn(test_data.AMPDS.appliance_Q(:,i),snr,'measured');
%     train_data_noise.AMPDS.appliance_P(train_data_noise.AMPDS.appliance_P<0)=0;
%     train_data_noise.AMPDS.appliance_Q(train_data_noise.AMPDS.appliance_Q<0)=0;
% %     test_data_noise.AMPDS.appliance_P(test_data_noise.AMPDS.appliance_P<0)=0;
% %     test_data_noise.AMPDS.appliance_Q(test_data_noise.AMPDS.appliance_Q<0)=0;
% end

% test_data.AMPDS.appliance_P=Total_P;

S=AMPDS_S(appliance_location);
always_On_appliance=AMPDS_alwaysOn(appliance_location);



cluster_id=[];
for i=1:length(select_appliance_name)
    eval(strcat('input_data=','[[1:size(train_data.',select_data_Set{1},'.appliance_',select_data_type{1},',1)]'',','train_data.',select_data_Set{1},'.appliance_',select_data_type{1},'(:,i)];'));
%     eval(strcat('input_data=','[[1:size(test_data.',select_data_Set{1},'.appliance_',select_data_type{1},',1)]'',','test_data.',select_data_Set{1},'.appliance_',select_data_type{1},'(:,i)];'));

    [result_Idx]=function_getStateNumByKmean(input_data(:,2),select_appliance_name{i},-1,S(i)); %%if want to use elbow rule ,change '-1' to 'i' 
    cluster_id=[cluster_id,result_Idx];
end
origin_cluster=[origin_cluster;cluster_id];
N = length(S); % �����豸����
state_size = sum(S);
T=test_data_num;
%% EMILP

[P, P_top, P_bottom, Q, Q_top, Q_bottom, State_Limit, P_test, Q_test, P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega, P_train,penlty_s,penlty_l,State_max_Limit] = DataProcessing_EMILP(train_data,test_data,select_appliance_name,select_data_type,select_data_Set,S,cluster_id,train_data_num,test_data_num,train_day_num,always_On_appliance);
Total_P=[Total_P;P_test];
P_test=num2cell(test_data.AMPDS.appliance_P,1);
% C_start=0.892;
% C_run=1.0419;
% % validate_day_num=6;
% % validate_data_num=60*24*validate_day_num;
% % validate_data_num=60*24*1;
% % validate_data_location=60*24*(train_day_num-validate_day_num)+1:60*24*(train_day_num-validate_day_num+1);%60*24*train_day_num;
% % [C_sart,C_run]=function_grid_search(P_top, P_bottom, Q_top, Q_bottom, State_Limit , train_data.AMPDS.appliance_P, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega,validate_data_num,S,1,validate_data_location,select_appliance_name,penlty_s,penlty_l,state_size,validate_data_num,N,10,10,10,10,always_On_appliance);
% 
% [model_EMILP] = function_construction_EMILP(P_top, P_bottom, Q_top, Q_bottom, State_Limit , P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega,test_data_num,S,test_day_num,penlty_s,penlty_l,C_start,C_run);
% disp('��ģ���');
% disp('��ʼ���');
% 
% 
% [result] = solve(model_EMILP,0.001,TIME);
% disp('������');
% % [x,fval,exitflag,output]= cplexmiqcp(H,f,Aineq,bineq,Aeq,beq,l,Q,r,sostype,sosind,soswt,lb,ub,ctype,x0,options)
% x_value=result.x;
% 
% EMILP_x=reshape(x_value(1:state_size*T),state_size,T);
% P_value = x_value(state_size*T*2+1:state_size*T*3, :); % ȡ����������Pit��ֵ
% device_state = x_value(1:state_size*T, :); % ȡ��0-1����Xit��ֵ 
% 
% Decompose_data = {};
% for  i= 1:N
%     decompose = [];
%     p1 = 1;
%     if (i > 1)
%         p1 = sum(S(:, 1:i-1))+1;
%     end
%     for t = 1:T
%         temp_value = device_state(p1:p1+S(:,i)-1, :)' * P_value(p1:p1+S(:,i)-1, :);
%         decompose = [decompose; temp_value];
%         p1 = p1+state_size;
%     end
%     Decompose_data = [Decompose_data; decompose];
% end
% disp('Decompose done!!');
% 
% 
% x_axis = 1:1:T; % T�����x����
% predict_sum = sparse(test_data_num, 1);
% figure(1)          % define figure
% for i = 1:N
%     predict_sum = predict_sum+Decompose_data{i};
%     subplot(N+2,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
%     plot(x_axis, Decompose_data{i}, x_axis, P_test{i});
%     legend('predict','true');
%     title(select_appliance_name{i});
% end
% subplot(N+2,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
% plot(x_axis, sparse(T,1), x_axis, abs(P_Sum-predict_sum));
% legend('predict','unknow');
% title('unknow device');
% 
% subplot(N+2,1,N+2);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
% plot(x_axis, predict_sum, x_axis, P_Sum);
% legend('predict','true');
% title('Total consumption');
% 
% EMILP_Power=[];
% for i=1:length(Decompose_data)
% EMILP_Power=[EMILP_Power,Decompose_data{i}];
% end
% % [RSE_EMILP, R_square_EMILP, AC_EMILP, h_predict_EMILP, h_true_EMILP, h_error_EMILP,OCC_EMILP,FS_EMILP] = evaluation_func(P_test, Decompose_data,EMILP_x,S,always_On_appliance);
% model_EMILP=[];
%% CMIP
index_VFP=[];
[P_CMILP, Q_CMILP, P_Sum,D_VFP] = function_dataProcess_VFP(select_appliance_name,select_data_type,select_data_Set, S, train_data, test_data, train_data_num,test_data_num,train_day_num,cluster_id,always_On_appliance,State_Limit,index_VFP);


[model,result_CMILP] = function_new_MF(P_Sum,S,P_CMILP,TIME,D_VFP,State_Limit,State_max_Limit,index_VFP,always_On_appliance);

results_CMILP=result_CMILP.appliance_power;
CMILP_x_state=result_CMILP.x_state;
Decompose_data = {};
x_axis = 1:1:T; % T�����x����
predict_sum = sparse(1, test_data_num);
figure(4)          % define figure
for i = 1:N
    predict_sum = predict_sum+results_CMILP(i, :);
    Decompose_data = [Decompose_data; results_CMILP(i, :)'];
    subplot(N+1,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
    plot(x_axis, results_CMILP(i, :), x_axis, P_test{i});
    legend('predict','true');
    title(select_appliance_name{i});
end
subplot(N+1,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
plot(x_axis, predict_sum, x_axis, P_Sum);
legend('predict','true');
title('Total consumption');


CMILP_Power=Decompose_data;
[RSE_CMILP, R_square_CMILP, AC_CMILP, h_predict_CMILP, h_true_CMILP, h_error_CMILP,OCC_CMILP,FS_CMILP] = evaluation_func(P_test, Decompose_data,CMILP_x_state,S,always_On_appliance);

%% CO
% [P_CO, Q_CO, P_Sum] = Easy_dataProcessing(select_appliance_name,select_data_type,select_data_Set, S, train_data, test_data, train_data_num,test_data_num,train_day_num,cluster_id,always_On_appliance,State_Limit);
% disp('data processing Done!');
% 
% 
% P_feature = {};
% p = 1;
% for i =1:N
%     P_feature = [P_feature; P_CO(p:p+S(:, i)-1, :)];
%     p=p+S(:, i);
% end
% [model,result_CO] = function_construct_CO(P_Sum,S,P_feature,TIME);
% results_CO=result_CO.appliance_power;
% CO_x=result_CO.x_state;
% Decompose_data = {};
% x_axis = 1:1:T; % T�����x����
% predict_sum = sparse(1, test_data_num);
% figure(2)          % define figure
% for i = 1:N
%     predict_sum = predict_sum+results_CO(i, :);
%     Decompose_data = [Decompose_data; results_CO(i, :)'];
%     subplot(N+1,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
%     plot(x_axis, results_CO(i, :), x_axis, P_test{i});
%     legend('predict','true');
%     title(select_appliance_name{i});
% end
% subplot(N+1,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
% plot(x_axis, predict_sum, x_axis, P_Sum);
% legend('predict','true');
% title('Total consumption');
% 
% 
% CO_Power=Decompose_data;
% [RSE_CO, R_square_CO, AC_CO, h_predict_CO, h_true_CO, h_error_CO,OCC_CO,FS_CO] = evaluation_func(P_test, Decompose_data,CO_x,S,always_On_appliance);
%% SO
% [P_SO, Q_SO, P_Sum, Transition_model, Omega,penlty_w] = Easy_dataProcessing(select_appliance_name,select_data_type,select_data_Set, S, train_data,test_data,train_data_num,test_data_num,train_day_num,cluster_id,always_On_appliance,State_Limit);
% 
% P_feature = {};
% p = 1;
% for i =1:N
%     P_feature = [P_feature; P_SO(p:p+S(:, i)-1, :)];
%     p=p+S(:, i);
% end
% 
% u1=10; 
% u2=750; 
%  [model,result_SO] = function_construct_SO(P_Sum,S,[],P_feature,penlty_w,Omega',u1,u2,TIME);
% % [model,result_SO] = function_construct_SO_improve(P_Sum,S,[],P_feature,penlty_w,Omega',u1,u2,TIME);
% results_SO=result_SO.appliance_power;
% SO_x_state=result_SO.x_state;
% Decompose_data = {};
% x_axis = 1:1:T; % T�����x����
% predict_sum = sparse(1, test_data_num);
% figure(3)          % define figure
% for i = 1:N
%     predict_sum = predict_sum+results_SO(i, :);
%     Decompose_data = [Decompose_data; results_SO(i, :)'];
%     subplot(N+1,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
%     plot(x_axis, results_SO(i, :), x_axis, P_test{i});
%     legend('predict','true');
%     title(select_appliance_name{i});
% end
% subplot(N+1,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
% plot(x_axis, predict_sum, x_axis, P_Sum);
% legend('predict','true');
% title('Total consumption');
% 
% 
% SO_Power=Decompose_data;
% 
%  [RSE_SO, R_square_SO, AC_SO, h_predict_SO, h_true_SO, h_error_SO,OCC_SO] = evaluation_func(P_test, Decompose_data,SO_x_state,S,always_On_appliance);

%% OLDA
% [P_OLDA, Q_OLDA, P_Sum, Transition_model, Omega] = Easy_dataProcessing(select_appliance_name,select_data_type,select_data_Set, S, train_data,test_data,train_data_num,test_data_num,train_day_num,cluster_id,always_On_appliance,State_Limit);
% disp('data processing Done!');
% 
% 
% P_feature = {};
% p = 1;
% for i =1:N
%     P_feature = [P_feature; P_OLDA(p:p+S(:, i)-1, :)];
%     p=p+S(:, i);
% end
% penlty_l = Omega;
% % p =1;
% % for i =1:N
% %     penlty_l = [penlty_l, sum(Omega(p:p+S(:, i)-1, :))/S(:, i)];
% %     p=p+S(:, i);
% % end
% 
% u = 1000;
% state_change_matr = Transition_model;
% [model, result_OLDA] = function_construct_OLDA(P_Sum, S, state_change_matr, P_feature, penlty_l, u,TIME);
% results_OLDA=result_OLDA.appliance_power;
% OLDA_x_state=result_OLDA.x_state;
% Decompose_data = {};
% x_axis = 1:1:T; % T�����x����
% predict_sum = sparse(1, test_data_num);
% figure(4)          % define figure
% for i = 1:N
%     predict_sum = predict_sum+results_OLDA(i, :);
%     Decompose_data = [Decompose_data; results_OLDA(i, :)'];
%     subplot(N+1,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
%     plot(x_axis, results_OLDA(i, :), x_axis, P_test{i});
%     legend('predict','true');
%     title(select_appliance_name{i});
% end
% subplot(N+1,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
% plot(x_axis, predict_sum, x_axis, P_Sum);
% legend('predict','true');
% title('Total consumption');
% 
% 
% OLDA_Power=Decompose_data;
% [RSE_OLDA, R_square_OLDA, AC_OLDA, h_predict_OLDA, h_true_OLDA, h_error_OLDA,OCC_OLDA,FS_OLDA] = evaluation_func(P_test, Decompose_data,OLDA_x_state,S,always_On_appliance);
% % 



%% ALIP

% [P, P_top, P_bottom, State_Limit, P_test, P_Sum, P_up, P_down,Transition_model, C, P_train] = RealDataProcessing_v1(select_appliance_name,select_data_type,select_data_Set, S, train_data,test_data,train_data_num,test_data_num,train_day_num,cluster_id,always_On_appliance);
% 
% disp('data processing Done!');
% 
% 
% error_num = 10;
% 
%  [Equal_sum_matri, Power_Equal_matri, P_feature, P_max, P_min] = function_ALIP_martix(P_top, P_bottom, P, S, always_On_appliance, error_num);
% 
% testData = P_Sum;
% class_num = S+always_On_appliance-1;
%  
% [model_ALIP, result_ALIP] = function_construct_ALIP(testData,class_num,P_feature,always_On_appliance,P_max,P_min, Equal_sum_matri, Power_Equal_matri,Transition_model,TIME);
% results_ALIP=result_ALIP.appliance_power;
% ALIP_x_state=result_ALIP.x_state;
% 
% T = test_data_num;
% 
% P_test=num2cell(P_test,1);
% Decompose_data = {};
% x_axis = 1:1:T; % T�����x����
% predict_sum = sparse(1, test_data_num);
% figure(5)          % define figure
% for i = 1:N
%     predict_sum = predict_sum+results_ALIP(i, :);
%     Decompose_data = [Decompose_data; results_ALIP(i, :)'];
%     subplot(N+1,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
%     plot(x_axis, results_ALIP(i, :), x_axis, P_test{i});
%     legend('predict','true');
%     title(select_appliance_name{i});
% end
% subplot(N+1,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
% plot(x_axis, predict_sum', x_axis, testData);
% legend('predict','true');
% title('Total consumption');
% 
% 
% ALIP_Power=Decompose_data;
% [RSE_ALIP, R_square_ALIP, AC_ALIP, h_predict_ALIP, h_true_ALIP, h_error_ALIP,OCC_ALIP] = evaluation_func(P_test, Decompose_data,ALIP_x_state,S,always_On_appliance);




%% BQP

% [P_BQP, Q_BQP, P_Sum, Transition_model, Omega,penlty_w_tmp,minActiveTime_tmp,maxActiveTime_tmp,maxUpwardTransition_tmp,maxPower,maxPower_peroid] = Easy_dataProcessing(select_appliance_name,select_data_type,select_data_Set,S, train_data,test_data,train_data_num,test_data_num,train_day_num,cluster_id,always_On_appliance,State_Limit);
% 
% 
% 
% N=length(appliance_location);
% P_feature = {};
% minActiveTime=[];
% maxActiveTime=[];
% maxUpwardTransition=[];
% penlty_w=[];
%     p = 1;
%     for i =1:N
%         if (always_On_appliance(1, i) == 0 )
%             P_feature = [P_feature; P_BQP(p+1:p+S(:, i)-1, :)];
%             minActiveTime = [minActiveTime; State_Limit(p+1:p+S(:, i)-1, :)];
%             maxActiveTime = [maxActiveTime; State_max_Limit(p+1:p+S(:, i)-1, :)];
%             maxUpwardTransition = [maxUpwardTransition; maxUpwardTransition_tmp(p+1:p+S(:, i)-1, :)];
%             penlty_w = [penlty_w; penlty_w_tmp(p+1:p+S(:, i)-1, :)];
%             p=p+S(:, i);
%             Transition_model_temp=Transition_model{i};
%             Transition_model{i}=Transition_model_temp(2:S(i),2:S(i));
%         else
%             P_feature = [P_feature; P_BQP(p:p+S(:, i)-1, :)];
%             minActiveTime = [minActiveTime; State_Limit(p:p+S(:, i)-1, :)];
%             maxActiveTime = [maxActiveTime; State_max_Limit(p:p+S(:, i)-1, :)];
%             maxUpwardTransition = [maxUpwardTransition; maxUpwardTransition_tmp(p:p+S(:, i)-1, :)];
%             penlty_w = [penlty_w; penlty_w_tmp(p:p+S(:, i)-1, :)];
%             p=p+S(:, i);
%         end
% 
%     end
% 
% u1=1000;
% u2=2000;
% testData = P_Sum;
% 
%  [model,result_BQP] = function_construct_BQP(testData,S,Transition_model,P_feature,always_On_appliance,minActiveTime,maxActiveTime,maxUpwardTransition,maxPower,maxPower_peroid,penlty_w,Omega,u1,u2,TIME);
% 
% 
% results_BQP=result_BQP.appliance_power;
% BQP_x_state=result_BQP.x_state;
% 
% T = test_data_num;
% 
% 
% Decompose_data = {};
% x_axis = 1:1:T; % T�����x����
% predict_sum = sparse(1, test_data_num);
% figure(6)          % define figure
% for i = 1:N
%     predict_sum = predict_sum+results_BQP(i, :);
%     Decompose_data = [Decompose_data; results_BQP(i, :)'];
%     subplot(N+1,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
%     plot(x_axis, results_BQP(i, :), x_axis, P_test{i});
%     legend('predict','true');
%     title(select_appliance_name{i});
% end
% subplot(N+1,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
% plot(x_axis, predict_sum', x_axis, testData);
% legend('predict','true');
% title('Total consumption');
% 
% 
% BQP_Power=Decompose_data;
% [RSE_BQP, R_square_BQP, AC_BQP, h_predict_BQP, h_true_BQP, h_error_BQP,OCC_BQP,FS_BQP] = evaluation_func(P_test, Decompose_data,BQP_x_state,S,always_On_appliance);
% % 
% % 
% 





%% 
% CO_state=[CO_state,CO_x];
% SO_state=[SO_state,SO_x_state];
% OLDA_state=[OLDA_state,OLDA_x_state];
%ALIP_state=[ALIP_state,ALIP_x_state];
% BQP_state=[BQP_state,BQP_x_state];
% EMILP_state=[EMILP_state,EMILP_x];
CMILP_state=[CMILP_state,CMILP_x_state];

% CO_power=[CO_power,results_CO];
% SO_power=[SO_power,results_SO];
% OLDA_power=[OLDA_power,results_OLDA];
% ALIP_power=[ALIP_power,results_ALIP];
% BQP_power=[BQP_power,results_BQP];
% EMILP_power=[EMILP_power,EMILP_Power'];
CMILP_power=[CMILP_power,results_CMILP];


% RSE=[RSE_CO,RSE_SO,RSE_ALIP,RSE_OLDA,RSE_BQP,RSE_EMILP];
% R_square=[R_square_CO,R_square_SO,R_square_ALIP,R_square_OLDA,R_square_BQP,R_square_EMILP];
% AC=[AC_CO,AC_SO,AC_ALIP,AC_OLDA,AC_BQP,AC_EMILP];
% h_error=[h_error_CO,h_error_SO,h_error_ALIP,h_error_OLDA,h_error_BQP,h_error_EMILP];
% OCC=[OCC_CO,OCC_SO,OCC_ALIP,OCC_OLDA,OCC_BQP,OCC_EMILP];
% FS=[FS_CO,FS_SO,FS_ALIP,FS_OLDA,FS_BQP,FS_EMILP];
% time=[result_CO.runtime,result_SO.runtime,result_ALIP.runtime,result_OLDA.runtime,result_BQP.runtime,result.runtime];


% RSE=[RSE_CO,RSE_SO,RSE_ALIP,RSE_EMILP];
% R_square=[R_square_CO,R_square_SO,R_square_ALIP,R_square_EMILP];
% AC=[AC_CO,AC_SO,AC_ALIP,AC_EMILP];
% h_error=[h_error_CO,h_error_SO,h_error_ALIP,h_error_EMILP];
% OCC=[OCC_CO,OCC_SO,OCC_ALIP,OCC_EMILP];
% FS=[FS_CO,FS_SO,FS_ALIP,FS_EMILP];
% time=[result_CO.runtime,result_SO.runtime,result_ALIP.runtime,result.runtime];





% RSE=[RSE_CO,RSE_SO,RSE_ALIP,RSE_EMILP];
% R_square=[R_square_CO,R_square_SO,R_square_ALIP,R_square_EMILP];
% AC=[AC_CO,AC_SO,AC_ALIP,AC_EMILP];
% h_error=[h_error_CO,h_error_SO,h_error_ALIP,h_error_EMILP];
% time=[result_CO.runtime,result_SO.runtime,result_ALIP.runtime,result.runtime];


% OLDA_result=[];
% EMILP_result=[EMILP_result;RSE_EMILP,R_square_EMILP,AC_EMILP,h_error_EMILP,[OCC_EMILP;sparse(size(RSE_EMILP,1)-1,size(OCC_EMILP,2))],FS_EMILP,[result.runtime;sparse(size(RSE_EMILP,1)-1,1)]];
% SO_result=[SO_result;AC_SO]

% OLDA_result=[OLDA_result;RSE_OLDA,R_square_OLDA,AC_OLDA,h_error_OLDA,[OCC_OLDA;sparse(size(RSE_OLDA,1)-1,size(OCC_OLDA,2))],FS_OLDA,[result_OLDA.runtime;sparse(size(RSE_OLDA,1)-1,1)]];
% 
% 
% BQP_result=[BQP_result;RSE_BQP,R_square_BQP,AC_BQP,h_error_BQP,[OCC_BQP;sparse(size(RSE_BQP,1)-1,size(OCC_BQP,2))],FS_BQP,[result_BQP.runtime;sparse(size(RSE_BQP,1)-1,1)]];


 CMILP_result=[CMILP_result;RSE_CMILP,R_square_CMILP,AC_CMILP,h_error_CMILP,[OCC_CMILP;sparse(size(RSE_CMILP,1)-1,size(OCC_CMILP,2))],FS_CMILP,[result_CMILP.runtime;sparse(size(RSE_CMILP,1)-1,1)]];


% result_data=[RSE,R_square,AC,h_error,[OCC;sparse(size(RSE,1)-1,size(OCC,2))],FS,[time;sparse(size(RSE,1)-1,size(time,2))]];
% % % % 
% writematrix(result_data,result_path,'Delimiter','tab','WriteMode','append');
% writecell(EMILP_Power,strcat('result/AMPDS/Power_EMILP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
% writecell(CO_Power,strcat('result/AMPDS/Power_CO_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
% writecell(SO_Power,strcat('result/AMPDS/Power_SO_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
% writecell(OLDA_Power,strcat('result/AMPDS/Power_OLDA_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
% writecell(ALIP_Power,strcat('result/AMPDS/Power_ALIP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
% writecell(BQP_Power,strcat('result/AMPDS/Power_BQP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');

% [NSAC_EMILP] = function_NSAC(strcat('result/AMPDS/Power_EMILP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
% [NSAC_CO] = function_NSAC(strcat('result/AMPDS/Power_CO_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
% [NSAC_SO] = function_NSAC(strcat('result/AMPDS/Power_SO_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
% [NSAC_OLDA] = function_NSAC(strcat('result/AMPDS/Power_OLDA_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
% [NSAC_ALIP] = function_NSAC(strcat('result/AMPDS/Power_ALIP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
% [NSAC_BQP] = function_NSAC(strcat('result/AMPDS/Power_BQP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
% 
% NSAC=[NSAC;NSAC_CO,NSAC_SO,NSAC_ALIP,NSAC_OLDA,NSAC_BQP,NSAC_EMILP];
end
%     EMILP_result=[EMILP_result;sparse(1,size(EMILP_result,2))];
% end
