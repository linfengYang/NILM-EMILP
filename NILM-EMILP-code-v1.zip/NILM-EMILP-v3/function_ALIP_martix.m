function [Equal_sum_matri, Power_Equal_matri, P_feature, P_max, P_min] = function_ALIP_martix(P_top, P_bottom, P, S, alway_on_matri, error_num)
%ǰ����������State_size*1����������S��1*N������������ʾ�豸״̬��
    
    P_activate = [];
    [index_noAlways]=find(alway_on_matri==0);
    [index_Always]=find(alway_on_matri==1);
    remove_ZeroState=alway_on_matri;
    remove_ZeroState(index_noAlways)=1;
    remove_ZeroState(index_Always)=0;
    S_activate = S -remove_ZeroState;
    max_activate = max(S_activate);
    N_activate = sum(S_activate);
    activate_state = [];
    N = length(S);
    for i = 1:N
        activate_state = [activate_state; i*ones(S_activate(1,i),1)];
    end
    
    appliance_num=length(S);
    index_appliance=[];
    for i=1:appliance_num
        index_appliance=[index_appliance;i*ones(S(i),1)];
    end

  
    for i = 1:N
        [index]=find(index_appliance==i);
        if(alway_on_matri(i)==0)
            [nonZeroState]=find(P(index)~=min(P(index)));
            P_activate = [P_activate; P(index(nonZeroState))];
            
        else
            P_activate = [P_activate; P(index)];
        end
    end

    combination_list = {};
    All_index = [1:N_activate];
    for i = 2:N-1
        combination_i = nchoosek(All_index, i); % �豸��ϱ��
        for j = 1:length(combination_i(:, 1))
             if (length(activate_state(combination_i(j,:))) ~= length(unique(activate_state(combination_i(j, :))))) %todo �ж��Ƿ�������Ԫ��
                continue;
            else
                combination_list = [combination_list; combination_i(j,:)];
            end
        end

    end

    martix1 = [];

    power_combination_list = {};
     for j = 1:size(combination_list)
         block = struct; 
         power_sum = sum(P_activate(combination_list{j}, 1));
         block.power = power_sum;
         block.combination = combination_list{j};
         power_combination_list = [power_combination_list; block];
     end

     martix2 = {};
     for i = 2:N-1
         block2 = struct;
         block2.num = i;
         rows_cell = {}
          for j = 1:size(power_combination_list)
              if (length(power_combination_list{j}.combination) == i)
                  rows_cell = [rows_cell; power_combination_list{j}];
              end
          end
          block2.comlist = rows_cell; 
          martix2 = [martix2; block2];
     end


    martix3 = [];
     for i = 1:size(martix2)
        comlist = martix2{i}.comlist;
        for j = 1:N_activate
             for k = 1:size(comlist)
                if (length(comlist{k}.combination(find(comlist{k}.combination == j))) == 0) % ���ж�j����������
                    if (abs(P_activate(j, :) - comlist{k}.power) < error_num) % ���жϹ��ʲ���Ƿ�С�ڿɽ��ܷ�Χ
                        temp_rows = zeros(1, N_activate);
                        temp_rows(comlist{k}.combination) = 1;
                        temp_rows(j) = 1;
                        martix3 = [martix3; temp_rows];
                    end
                end
             end
        end
     end

     martix4 = [];
     if(~isempty(martix3))
         for i =1:length(martix3(:, 1))
             rows = martix3(i, :);
             p = 1;
             flag = 1;
             for j = 1:N
                 if (S_activate(:, j) == 1)
                     p = p+S_activate(:, j);
                     continue;
                 end
                 if (sum(rows(1, p:p+S_activate(:, j)-1)) > 1)
                     flag = 0;
                 end
                 p = p+S_activate(:, j);
             end
             if (flag == 1)
                 martix4 = [martix4; rows];
             end
         end
     end
    martix5 = [];
    for i = 1:N_activate
        rows = zeros(1, N_activate);
        for j = 1:N_activate
            if (i == j)
                continue;
            end
            if (abs(P_activate(i, :) - P_activate(j, :)) < error_num)
                rows(1, [i, j]) = 1;
                martix5 = [martix5; rows];
            end
        end
    end

     martix6 = [];
     if(~isempty(martix5))
         for i =1:length(martix5(:, 1))
             rows = martix5(i, :);
             p = 1;
             flag = 1;
             for j = 1:N
                 if (S_activate(:, j) == 1)
                     p = p+S_activate(:, j);
                     continue;
                 end
                 if (sum(rows(1, p:p+S_activate(:, j)-1)) > 1)
                     flag = 0;
                 end
                 p = p+S_activate(:, j);
             end
             if (flag == 1)
                 martix6 = [martix6; rows];
             end
         end
     end
    Equal_sum_matri = martix4;

    Power_Equal_matri = martix6;

    P_feature = {};
    P_max = {};
    P_min = {};
    p = 1;
    for i =1:N
        if (alway_on_matri(1, i) == 0 )
            P_feature = [P_feature; P(p+1:p+S(:, i)-1, :)];
            P_max = [P_max; P_top(p+1:p+S(:, i)-1, :)];
            P_min = [P_min; P_bottom(p+1:p+S(:, i)-1, :)];
            p=p+S(:, i);
        else
            P_feature = [P_feature; P(p:p+S(:, i)-1, :)];
            P_max = [P_max; P_top(p:p+S(:, i)-1, :)];
            P_min = [P_min; P_bottom(p:p+S(:, i)-1, :)];
            p=p+S(:, i);
        end
    end
%     for i = 1:N
%             P_feature = [P_feature; P(p:p+S(:, i)-1, :)];
%             P_max = [P_max; P_top(p:p+S(:, i)-1, :)];
%             P_min = [P_min; P_bottom(p:p+S(:, i)-1, :)];
%             p=p+S(:, i);
%     end
    
    
end