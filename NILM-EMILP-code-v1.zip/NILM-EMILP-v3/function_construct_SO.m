function [model,result] = function_construct_SO(testData,class_num,state_change_matr,P_feature,penlty_w,penlty_k,u1,u2,TIME)
%FUNCTION_CONSTRUCT_SO �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

N=sum(class_num);
appliance_num=length(class_num);
T=length(testData);
Total_variable_num=N*T;
variable_num=[0,class_num*T];
state_variable_location(:,1)=1:T:Total_variable_num;
state_variable_location(:,2)=[state_variable_location(2:end,1)-1;Total_variable_num];
for i=2:length(variable_num)
    appliance_variable_location(i-1,1)=sum(variable_num(1:i-1))+1;
    appliance_variable_location(i-1,2)=sum(variable_num(1:i));
end

index_appliance=[];
for i=1:appliance_num
    index_appliance=[index_appliance;i*ones(class_num(i),1)];
end

decision_var_location=1:Total_variable_num;

auxily_var_location_z1=Total_variable_num+1:Total_variable_num+N*T;
Total_variable_num=Total_variable_num+length(auxily_var_location_z1);

auxily_var_location_z2=Total_variable_num+1:Total_variable_num+appliance_num*(T-1);
Total_variable_num=Total_variable_num+length(auxily_var_location_z2);

if(length(testData)/size(penlty_w,2)==round(length(testData)/size(penlty_w,2)))
  penlty_w=repmat(penlty_w,1,length(testData)/size(penlty_w,2));
else
    if((length(testData)/size(penlty_w,2))<1)
    penlty_w=penlty_w(:,1:length(testData));
    else
        penlty_w=repmat(penlty_w,1,floor(length(testData)/size(penlty_w,2)));
        penlty_w=[penlty_w,penlty_w(:,mod(length(testData)/size(penlty_w,2)),floor(length(testData)/size(penlty_w,2)))];
    end
end
penlty_w=reshape(penlty_w',1,length(auxily_var_location_z1));
% penlty_w=ones(1,length(auxily_var_location_z1));
%% 


Q_nonDiag=sparse(Total_variable_num,Total_variable_num);
for i=1:N-1
    Q_other=sparse(Total_variable_num,Total_variable_num);
    Q_other(1:(N-i)*T,i*T+1:N*T)=sparse([1:(N-i)*T],[1:(N-i)*T],ones((N-i)*T,1),(N-i)*T,(N-i)*T);
    Q_nonDiag=Q_other+Q_nonDiag;
end
appliance_Power_vector=[];
P_feature_verctor=sparse(Total_variable_num,1);
for i=1:length(P_feature)
    P_feature_verctor(appliance_variable_location(i,1):appliance_variable_location(i,2))=...
        reshape(repmat(P_feature{i},1,T)',length(P_feature{i})*T,1);
    appliance_Power_vector=[appliance_Power_vector;P_feature{i}];
end

for i=1:appliance_num
    [row_temp,col_temp,value_temp]=find(Q_nonDiag(appliance_variable_location(i,1):appliance_variable_location(i,2),:)~=0);
    Q_nonDiag(appliance_variable_location(i,1):appliance_variable_location(i,2),decision_var_location)=...
        sparse(row_temp,col_temp,value_temp.*(P_feature_verctor(row_temp).*P_feature_verctor(col_temp)),length([appliance_variable_location(i,1):appliance_variable_location(i,2)]),length(decision_var_location));
end

Q_diag=sparse([1:Total_variable_num],[1:Total_variable_num],P_feature_verctor.^2,Total_variable_num,Total_variable_num);

Q=Q_nonDiag+Q_nonDiag'+Q_diag;

%һ����
f=sparse(Total_variable_num,1);
f(decision_var_location)=-2*reshape(repmat(testData,1,N),length(decision_var_location),1).*...
    P_feature_verctor(decision_var_location);
f(auxily_var_location_z1)=u1*penlty_w;
f(auxily_var_location_z2)=u2*reshape(repmat(penlty_k,T-1,1),length(auxily_var_location_z2),1);

%Լ��
%Single_Mode_Operation
Aeq_Single_Mode_Operation=[];
beq_Single_Mode_Operation=[];

for i=1:appliance_num
    
    constraint_Single_Mode_Operation=sparse(T,Total_variable_num);
    location_vector=find(index_appliance==i);
    for j=1:class_num(i)
        
        constraint_Single_Mode_Operation(:,...
            state_variable_location(location_vector(j),1):...
            state_variable_location(location_vector(j),2))=...
            sparse([1:T],[1:T],ones(T,1),T,T);
    end
    Aeq_Single_Mode_Operation=[Aeq_Single_Mode_Operation;constraint_Single_Mode_Operation];
    beq_Single_Mode_Operation=[beq_Single_Mode_Operation;ones(T,1)];
end

%Auxily constraint
Aineq_Auxily_constraint=[];
bineq_Auxily_constraint=[];

constraint_Auxily_constraint=sparse(length(decision_var_location),Total_variable_num);
constraint_Auxily_constraint(1:length(decision_var_location),decision_var_location)=sparse([1:length(decision_var_location)],[1:length(decision_var_location)],ones(length(decision_var_location),1),length(decision_var_location),length(decision_var_location));
constraint_Auxily_constraint(1:length(decision_var_location),auxily_var_location_z1)=sparse([1:length(decision_var_location)],[1:length(auxily_var_location_z1)],-1*ones(length(decision_var_location),1),length(decision_var_location),length(auxily_var_location_z1));

Aineq_Auxily_constraint=[Aineq_Auxily_constraint;constraint_Auxily_constraint];
bineq_Auxily_constraint=[bineq_Auxily_constraint;sparse(length(decision_var_location),1)];

constraint_Auxily_constraint=sparse(length(decision_var_location),Total_variable_num);
constraint_Auxily_constraint(1:length(decision_var_location),decision_var_location)=sparse([1:length(decision_var_location)],[1:length(decision_var_location)],-1*ones(length(decision_var_location),1),length(decision_var_location),length(decision_var_location));
constraint_Auxily_constraint(1:length(decision_var_location),auxily_var_location_z1)=sparse([1:length(decision_var_location)],[1:length(auxily_var_location_z1)],-1*ones(length(decision_var_location),1),length(decision_var_location),length(auxily_var_location_z1));

Aineq_Auxily_constraint=[Aineq_Auxily_constraint;constraint_Auxily_constraint];
bineq_Auxily_constraint=[bineq_Auxily_constraint;sparse(length(decision_var_location),1)];


%
for i=1:N
constraint_Auxily_constraint=sparse(T-1,Total_variable_num);
constraint_Auxily_constraint(:,state_variable_location(i,1):state_variable_location(i,2))=...
    [sparse(T-1,1),sparse([1:T-1],[1:T-1],ones(T-1,1),T-1,T-1)]+...
    [sparse([1:T-1],[1:T-1],-1*ones(T-1,1),T-1,T-1),sparse(T-1,1)];
constraint_Auxily_constraint(:,...
    length(decision_var_location)+length(auxily_var_location_z1)+(index_appliance(i)-1)*(T-1)+1:...
    length(decision_var_location)+length(auxily_var_location_z1)+index_appliance(i)*(T-1))=...
    sparse([1:T-1],[1:T-1],-1*ones(T-1,1),T-1,T-1);

Aineq_Auxily_constraint=[Aineq_Auxily_constraint;constraint_Auxily_constraint];
bineq_Auxily_constraint=[bineq_Auxily_constraint;sparse(size(constraint_Auxily_constraint,1),1)];
end
    

%
constraint_cannot_change_simulaneously=[];
for i=1:appliance_num
    constraint_cannot_change_simulaneously=[constraint_cannot_change_simulaneously,sparse([1:T-1],[1:T-1],ones(T-1,1),T-1,T-1)];
end
constraint_cannot_change=sparse(T-1,length(auxily_var_location_z2));
constraint_cannot_change(:,auxily_var_location_z2)=constraint_cannot_change_simulaneously;
Aineq_Auxily_constraint=[Aineq_Auxily_constraint;constraint_cannot_change];
bineq_Auxily_constraint=[bineq_Auxily_constraint;ones(size(constraint_cannot_change,1),1)];  

Aeq=[Aeq_Single_Mode_Operation];
beq=[beq_Single_Mode_Operation];
Aineq=[Aineq_Auxily_constraint];
bineq=[bineq_Auxily_constraint];
lb=sparse(Total_variable_num,1);
lb(auxily_var_location_z1)=-inf;
lb(auxily_var_location_z2)=-inf;
ub=ones(Total_variable_num,1);
ub(auxily_var_location_z1)=inf;
ub(auxily_var_location_z2)=inf;
ctype='';
ctype(1:Total_variable_num)='C';
ctype(decision_var_location)='B';

model.Q=Q;
model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;


% options = cplexoptimset;
% options.Display='on';
% options.mip.tolerances.mipgap=3e-5;
% options.timelimit=1000;
% [x,fval,exitflag,output] = cplexmiqp(2*Q,f,Aineq,bineq,Aeq,beq,[],[],[],lb,ub,ctype);%,[],options);
[results] = solve(model,0.001,TIME);
x_state=reshape(results.x(decision_var_location),T,N)';
power_state=repmat(appliance_Power_vector,1,T).*x_state;
for i=1:appliance_num
    row_index=find(index_appliance==i);
    appliance_power(i,:)=sum(power_state(row_index,:),1);
end
result.x_state=x_state;
result.appliance_power=appliance_power;
result.runtime=results.runtime;
end

