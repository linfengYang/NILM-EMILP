function [model,result] = function_construct_BQP(testData,S,state_change_matr,P_feature,alway_on_matri,minActiveTime,maxActiveTime,maxUpwardTransition,maxPower,maxPower_peroid,penlty_w,penlty_k,u1,u2,TIME)
%FUNCTION_CONSTRUCT_BQP �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��


class_num = S+alway_on_matri-1;
N=sum(class_num);
appliance_num=length(class_num);
T=length(testData);
Total_variable_num=N*T;
%x location
variable_num=[0,class_num*T];
state_variable_location(:,1)=1:T:Total_variable_num;
state_variable_location(:,2)=[state_variable_location(2:end,1)-1;Total_variable_num];

%u location
u_variable_num=[N*T,class_num*T];
u_variable_location(:,1)=N*T+1:T:2*N*T;
u_variable_location(:,2)=[u_variable_location(2:end,1)-1;2*N*T];


%d location
d_variable_num=[2*N*T,class_num*T];
d_variable_location(:,1)=2*N*T+1:T:3*N*T;
d_variable_location(:,2)=[d_variable_location(2:end,1)-1;3*N*T];


for i=2:length(variable_num)
    appliance_variable_location(i-1,1)=sum(variable_num(1:i-1))+1;
    appliance_variable_location(i-1,2)=sum(variable_num(1:i));
    
    appliance_u_location(i-1,1)=sum(u_variable_num(1:i-1))+1;
    appliance_u_location(i-1,2)=sum(u_variable_num(1:i));
    
    appliance_d_location(i-1,1)=sum(d_variable_num(1:i-1))+1;
    appliance_d_location(i-1,2)=sum(d_variable_num(1:i));
end

if(size(penlty_w,2)==T)
    penlty_w=reshape(penlty_w',[1,N*T]);
else
    if(size(penlty_w,2)>T)
        penlty_w=penlty_w(:,1:T);
        
    else
        penlty_w=repmat(penlty_w,1,T/size(penlty_w,2));
        penlty_w=reshape(penlty_w',[1,N*T]);
    end
end

index_appliance=[];
penlty_l=[];
for i=1:appliance_num
    index_appliance=[index_appliance;i*ones(class_num(i),1)];
    penlty_l=[penlty_l;penlty_k(i)*ones(class_num(i),1)];
end

decision_var_location=1:Total_variable_num;

u_var_location=Total_variable_num+1:Total_variable_num+N*T;
Total_variable_num=Total_variable_num+length(u_var_location);

d_var_location=Total_variable_num+1:Total_variable_num+N*T;
Total_variable_num=Total_variable_num+length(d_var_location);



%% Ŀ�꺯��

%quadr term

%the sum of squared differences
Q_nonDiag=sparse(Total_variable_num,Total_variable_num);
for i=1:N-1
    Q_other=sparse(Total_variable_num,Total_variable_num);
    Q_other(1:(N-i)*T,i*T+1:N*T)=sparse([1:(N-i)*T],[1:(N-i)*T],ones((N-i)*T,1),(N-i)*T,(N-i)*T);
    Q_nonDiag=Q_other+Q_nonDiag;
end
appliance_Power_vector=[];
P_feature_verctor=sparse(Total_variable_num,1);
for i=1:length(P_feature)
    P_feature_verctor(appliance_variable_location(i,1):appliance_variable_location(i,2))=...
        reshape(repmat(P_feature{i},1,T)',length(P_feature{i})*T,1);
    appliance_Power_vector=[appliance_Power_vector;P_feature{i}];
end

% for i=1:appliance_num
%     [row_temp,col_temp,value_temp]=find(Q_nonDiag(appliance_variable_location(i,1):appliance_variable_location(i,2),:)~=0);
%     Q_nonDiag(appliance_variable_location(i,1):appliance_variable_location(i,2),decision_var_location)=...
%         sparse(row_temp,col_temp,value_temp.*(P_feature_verctor(row_temp).*P_feature_verctor(col_temp)),length([appliance_variable_location(i,1):appliance_variable_location(i,2)]),length(decision_var_location));
% end

for i=1:length(decision_var_location)
    Q_nonDiag(:,i)=Q_nonDiag(:,i).*P_feature_verctor;
end

for i=1:length(decision_var_location)
    Q_nonDiag(i,:)=Q_nonDiag(i,:).*P_feature_verctor';
end

Q_diag=sparse([1:Total_variable_num],[1:Total_variable_num],P_feature_verctor.^2,Total_variable_num,Total_variable_num);

Q=Q_nonDiag+Q_nonDiag'+Q_diag;

%plenty term--penalizes large changes
Q_nonDiag=sparse(Total_variable_num,Total_variable_num);

for i=1:N
    Q_other=sparse([1:T-1],[2:T],-1*penlty_l(i)*ones(T-1,1),T,T);
    Q_nonDiag(state_variable_location(i,1):state_variable_location(i,2),state_variable_location(i,1):state_variable_location(i,2))=Q_other+Q_other';
end

diag_component=2*ones(T,1);
diag_component(1)=1;
diag_component(T)=1;
diag_component=repmat(diag_component,N,1);
diag_coefficent=reshape(repmat(penlty_l',T,1),N*T,1);

Q_Diag=sparse([1:N*T],[1:N*T],diag_component.*diag_coefficent,Total_variable_num,Total_variable_num);

Q=u1*(Q_nonDiag+Q_Diag)+Q;

%penalty term--the number of active appliance   
Q_Diag=sparse([1:N*T],[1:N*T],u2*penlty_w,Total_variable_num,Total_variable_num);

Q=Q+Q_Diag;

%first order
f=sparse(Total_variable_num,1);
f(decision_var_location)=-2*reshape(repmat(testData,1,N),length(decision_var_location),1).*...
    P_feature_verctor(decision_var_location);
%% Լ��

%Single_Mode_Operation
Aineq_Single_Mode_Operation=[];
bineq_Single_Mode_Operation=[];

Aeq_AlwaysOn_Mode_Operation=[];
beq_AlwaysOn_Mode_Operation=[];

for i=1:appliance_num
    
    constraint_Single_Mode_Operation=sparse(T,Total_variable_num);
    location_vector=find(index_appliance==i);
    for j=1:class_num(i)
        
        constraint_Single_Mode_Operation(:,...
            state_variable_location(location_vector(j),1):...
            state_variable_location(location_vector(j),2))=...
            sparse([1:T],[1:T],ones(T,1),T,T);
    end

    if(1~=alway_on_matri(i))
        Aineq_Single_Mode_Operation=[Aineq_Single_Mode_Operation;constraint_Single_Mode_Operation];
        bineq_Single_Mode_Operation=[bineq_Single_Mode_Operation;ones(T,1)];
    else
        Aeq_AlwaysOn_Mode_Operation=[Aeq_AlwaysOn_Mode_Operation;constraint_Single_Mode_Operation];
        beq_AlwaysOn_Mode_Operation=[beq_AlwaysOn_Mode_Operation;ones(T,1)];
    end
        
end

%state constraint
Aeq_state_constraint=[];
beq_state_constraint=[];

Aineq_state_constraint=[];
bineq_state_constraint=[];

for i=1:N
    state_constraint=sparse(T-1,Total_variable_num);
    state_constraint(:,state_variable_location(i,1):state_variable_location(i,2))=[sparse([1:T-1],[1:T-1],-1*ones(T-1,1),T-1,T-1),sparse(T-1,1)]+[sparse(T-1,1),sparse([1:T-1],[1:T-1],ones(T-1,1),T-1,T-1)];
    state_constraint(:,u_variable_location(i,1):u_variable_location(i,2))=[sparse(T-1,1),sparse([1:T-1],[1:T-1],-1*ones(T-1,1),T-1,T-1)];
    state_constraint(:,d_variable_location(i,1):d_variable_location(i,2))=[sparse(T-1,1),sparse([1:T-1],[1:T-1],ones(T-1,1),T-1,T-1)];
    Aeq_state_constraint=[Aeq_state_constraint;state_constraint];
    beq_state_constraint=[beq_state_constraint;sparse(T-1,1)];
    
    state_constraint=sparse(T,Total_variable_num);
    state_constraint(:,u_variable_location(i,1):u_variable_location(i,2))=sparse([1:T],[1:T],ones(T,1),T,T);
    state_constraint(:,d_variable_location(i,1):d_variable_location(i,2))=sparse([1:T],[1:T],ones(T,1),T,T);
    Aineq_state_constraint=[Aineq_state_constraint;state_constraint];
    bineq_state_constraint=[bineq_state_constraint;ones(T,1)];
end



%min/max active time constraint
Aineq_minOrMax_active_constraint=[];
bineq_minOrMax_active_constraint=[];

for i=1:N
    %min active constraint
    if(T>=minActiveTime(i))
        min_active_constraint=sparse(T-minActiveTime(i)+1,Total_variable_num);
        for j=1:minActiveTime(i)
            min_active_constraint(:,state_variable_location(i,1):state_variable_location(i,2))=min_active_constraint(:,state_variable_location(i,1):state_variable_location(i,2))+...
                sparse([1:T-minActiveTime(i)+1],[j:j+T-minActiveTime(i)],-1*ones(1,T-minActiveTime(i)+1),T-minActiveTime(i)+1,T);
        end
        min_active_constraint(:,u_variable_location(i,1):u_variable_location(i,2))=sparse([1:T-minActiveTime(i)+1],[1:T-minActiveTime(i)+1],minActiveTime(i)*ones(T-minActiveTime(i)+1,1),T-minActiveTime(i)+1,T);
        Aineq_minOrMax_active_constraint=[Aineq_minOrMax_active_constraint;min_active_constraint];
        bineq_minOrMax_active_constraint=[bineq_minOrMax_active_constraint;sparse(T-minActiveTime(i)+1,1)];
    else
        disp('error:Total time < minActiveTime');
        break;
    end
    
    %max active constraint
    if(T>maxActiveTime(i))
        max_active_constraint=sparse(T-maxActiveTime(i),Total_variable_num);
        for j=1:maxActiveTime(i)+1
            max_active_constraint(:,state_variable_location(i,1):state_variable_location(i,2))=max_active_constraint(:,state_variable_location(i,1):state_variable_location(i,2))+...
                sparse([1:T-maxActiveTime(i)],[j:j+T-maxActiveTime(i)-1],ones(1,T-maxActiveTime(i)),T-maxActiveTime(i),T);
        end
        Aineq_minOrMax_active_constraint=[Aineq_minOrMax_active_constraint;max_active_constraint];
        bineq_minOrMax_active_constraint=[bineq_minOrMax_active_constraint;maxActiveTime(i)*ones(T-maxActiveTime(i),1)];
    else
        disp('error:Total time < maxActiveTime');
        break;
    end
end



%mode translation constraint
Aeq_mode_translation_constraint=[];
beq_mode_translation_constraint=[];


% for i=1:appliance_num
%     state_mat=state_change_matr{i};
%     appliance_state_location=find(index_appliance==i);
%     for j=1:class_num(i)
%         state_mat(j,j)=0;
%         index_row=find(state_mat(j,:)==1);
%         if(length(index_row)<=1)
%             for k=1:length(index_row)
%                 mode_translation_constraint=sparse(T,Total_variable_num);
%                 mode_translation_constraint(:,d_variable_location(appliance_state_location(j),1):d_variable_location(appliance_state_location(j),2))=...
%                     sparse([1:T],[1:T],ones(T,1),T,T);
%                 mode_translation_constraint(:,u_variable_location(appliance_state_location(index_row(k)),1):u_variable_location(appliance_state_location(index_row(k)),2))=...
%                     sparse([1:T],[1:T],-1*ones(T,1),T,T);
%                 Aeq_mode_translation_constraint=[Aeq_mode_translation_constraint;mode_translation_constraint];
%                 beq_mode_translation_constraint=[beq_mode_translation_constraint;sparse(T,1)];
%             end
%         else
%             disp('the state of an appliance only translates to another one rather than multiple states');
%             break;
% %             for k=1:length(index_row)
% %                 mode_translation_constraint=sparse(T,Total_variable_num);
% %                 mode_translation_constraint(:,d_variable_location(appliance_state_location(j),1):d_variable_location(appliance_state_location(j),2))=...
% %                     sparse([1:T],[1:T],ones(T,1),T,T);
% %                 mode_translation_constraint(:,u_variable_location(appliance_state_location(index_row(k)),1):u_variable_location(appliance_state_location(index_row(k)),2))=...
% %                     sparse([1:T],[1:T],-1*ones(T,1),T,T);
% %                 Aeq_mode_translation_constraint=[Aeq_mode_translation_constraint;mode_translation_constraint];
% %                 beq_mode_translation_constraint=[beq_mode_translation_constraint;sparse(T,1)];
% %             end
%         end
%     end
% end




% upward transition bound
Aineq_upward_transition_bound=[];
bineq_upward_transition_bound=[];
for i=1:appliance_num
    upward_transition_bound=sparse(1,Total_variable_num);
    index_i=find(index_appliance==i);
    for j=1:class_num(i)
    upward_transition_bound(:,u_variable_location(index_i(j),1)+1:u_variable_location(index_i(j),2))=1;
    end
    Aineq_upward_transition_bound=[Aineq_upward_transition_bound;upward_transition_bound];
    bineq_upward_transition_bound=[bineq_upward_transition_bound;sum(maxUpwardTransition(index_i))];
end

%max power limit
Aineq_max_power_limit=[];
bineq_max_power_limit=[];

max_power_limit=sparse(T,Total_variable_num);
for i=1:N
    max_power_limit(:,state_variable_location(i,1):state_variable_location(i,2))=sparse([1:T],[1:T],P_feature_verctor(i)*ones(T,1),T,T);
end
Aineq_max_power_limit=[Aineq_max_power_limit;max_power_limit];
bineq_max_power_limit=[bineq_max_power_limit;testData];


%time period power limit
Aineq_time_period_power_limit=[];
bineq_time_period_power_limit=[];

for i=1:appliance_num
    index_state=find(index_appliance==i);
    for k=1:length(maxPower_peroid{i})
        constraint_time_period_power_limit=sparse(1,Total_variable_num);
        for j=1:class_num(i)
            location_index=state_variable_location(index_state(j),1):state_variable_location(index_state(j),2);
            constraint_time_period_power_limit(:,location_index(maxPower_peroid{i}{k}))=P_feature{i}(j);
        end
        Aineq_time_period_power_limit=[Aineq_time_period_power_limit;constraint_time_period_power_limit];
        bineq_time_period_power_limit=[bineq_time_period_power_limit;maxPower(i,k)];
    end
end



Aeq=[Aeq_AlwaysOn_Mode_Operation;Aeq_state_constraint;Aeq_mode_translation_constraint];%;;];Aeq_mode_translation_constraint
beq=[beq_AlwaysOn_Mode_Operation;beq_state_constraint;beq_mode_translation_constraint];%;;];beq_mode_translation_constraint
Aineq=[Aineq_Single_Mode_Operation;Aineq_state_constraint;Aineq_minOrMax_active_constraint;Aineq_time_period_power_limit;Aineq_upward_transition_bound];%;];%;]; ; ;Aineq_max_power_limit
bineq=[bineq_Single_Mode_Operation;bineq_state_constraint;bineq_minOrMax_active_constraint;bineq_time_period_power_limit;bineq_upward_transition_bound];%;];%;;]; bineq_max_power_limit ;;bineq_max_power_limit
lb=sparse(Total_variable_num,1);
ub=ones(Total_variable_num,1);
ctype='';
ctype(1:Total_variable_num)='B';

model.Q=Q;
model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;

[results] = solve(model,0.001,TIME);
% options = cplexoptimset;
% options.Display='on';
% options.mip.tolerances.mipgap=3e-5;
% options.timelimit=1000;
% [x,fval,exitflag,output] = cplexmiqp(2*Q,f,Aineq,bineq,Aeq,beq,[],[],[],lb,ub,ctype);%,[],options);
x_state=reshape(results.x(decision_var_location),T,N)';
u_state=reshape(results.x(u_var_location),T,N)';
d_state=reshape(results.x(d_var_location),T,N)';
power_state=repmat(appliance_Power_vector,1,T).*x_state;
 for i=1:appliance_num
    row_index=find(index_appliance==i);
    appliance_power(i,:)=sum(power_state(row_index,:),1);
 end
result.x_state=x_state;
result.appliance_power=appliance_power;
result.runtime=results.runtime;



end

