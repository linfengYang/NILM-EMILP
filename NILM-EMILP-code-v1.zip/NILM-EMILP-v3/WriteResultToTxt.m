function WriteResultToTxt( fid,RSE,R_square,AC,h_error,time,index )
%WRITERESULTTOTXT �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
if(index==1)
    fprintf(fid,'index\t\t\t RSE\t\t\t R_square\t\t\t AC\t\t\t h_error\t\t\t time\n');
    fprintf(fid,'%d\t\t %f\t\t %f\t\t %f\t\t %f\t\t %f\n',index,RSE,R_square,AC,h_error,time);
else
    fprintf(fid,'%d\t\t %f\t\t %f\t\t %f\t\t %f\t\t %f\n',index,RSE,R_square,AC,h_error,time);
end
end

