function [model,result] = function_construct_ALIP(testData,class_num,P_feature,alway_on_matri,P_max,P_min, Equal_sum_matri, Power_Equal_matri,Transition_model,TIME)
%FUNCTION_CONSTRUCT_ALIP alway_on_matri is vector that includes the index of always-on
%appliance
%  P_feature��û��0��  ����״̬��Ϊ��0״̬
N=sum(class_num);
appliance_num=length(class_num);
T=length(testData);
Total_variable_num=N*T;
variable_num=[0,class_num*T];
state_variable_location(:,1)=1:T:Total_variable_num;
state_variable_location(:,2)=[state_variable_location(2:end,1)-1;Total_variable_num];
for i=2:length(variable_num)
    appliance_variable_location(i-1,1)=sum(variable_num(1:i-1))+1;
    appliance_variable_location(i-1,2)=sum(variable_num(1:i));
end

index_appliance=[];
for i=1:appliance_num
    index_appliance=[index_appliance;i*ones(class_num(i),1)];
end

decision_var_location=1:Total_variable_num;

auxily_var_location=Total_variable_num+1:Total_variable_num+T;


Total_variable_num=Total_variable_num+length(auxily_var_location);%��������

appliance_Power_vector=[];
appliance_Power_max_vector=[];
appliance_Power_min_vector=[];

for i=1:length(P_feature)
    appliance_Power_vector=[appliance_Power_vector;P_feature{i}];
    appliance_Power_max_vector=[appliance_Power_max_vector;P_max{i}];
    appliance_Power_min_vector=[appliance_Power_min_vector;P_min{i}];
end


%% Ŀ�꺯��
f=sparse(Total_variable_num,1);
f(auxily_var_location)=1;


%% Լ��
Aineq_constraint_difference=[];
bineq_constraint_difference=[];
xit=[];
for i=1:N
    x_part=sparse(diag(-1*appliance_Power_vector(i)*ones(1,T)));
    xit=[xit,x_part];
end
k_pt=sparse(diag(-1*ones(T,1)));

Aineq_constraint_difference=[Aineq_constraint_difference;xit,k_pt];
bineq_constraint_difference=[bineq_constraint_difference;-1*testData];

%
xit=[];
for i=1:N
    x_part=sparse(diag(appliance_Power_vector(i)*ones(1,T)));
    xit=[xit,x_part];
end
k_pt=sparse(diag(-1*ones(T,1)));
Aineq_constraint_difference=[Aineq_constraint_difference;xit,k_pt];
bineq_constraint_difference=[bineq_constraint_difference;testData];


%Single_Mode_Operation
Aineq_Single_Mode_Operation=[];
bineq_Single_Mode_Operation=[];

Aeq_AlwaysOn_Mode_Operation=[];
beq_AlwaysOn_Mode_Operation=[];

for i=1:appliance_num
    
    constraint_Single_Mode_Operation=sparse(T,Total_variable_num);
    location_vector=find(index_appliance==i);
    for j=1:class_num(i)
        
        constraint_Single_Mode_Operation(:,...
            state_variable_location(location_vector(j),1):...
            state_variable_location(location_vector(j),2))=...
            sparse([1:T],[1:T],ones(T,1),T,T);
    end

    if(1~=alway_on_matri(i))
        Aineq_Single_Mode_Operation=[Aineq_Single_Mode_Operation;constraint_Single_Mode_Operation];
        bineq_Single_Mode_Operation=[bineq_Single_Mode_Operation;ones(T,1)];
    else
        Aeq_AlwaysOn_Mode_Operation=[Aeq_AlwaysOn_Mode_Operation;constraint_Single_Mode_Operation];
        beq_AlwaysOn_Mode_Operation=[beq_AlwaysOn_Mode_Operation;ones(T,1)];
    end
end

%addtion constraint
Aineq_Equal_sum=[];
bineq_Equal_sum=[];
% Equal_sum_matri=Equal_sum_matri(1:5,:);
for i=1:size(Equal_sum_matri,1)
    constraint_Equal_sum=sparse(T,Total_variable_num);
    index_row=find(Equal_sum_matri(i,:)==1);
    for j=1:length(index_row)
        constraint_Equal_sum(:,state_variable_location(index_row(j),1):...
            state_variable_location(index_row(j),2))=...
            sparse([1:T],[1:T],ones(T,1),T,T);
    end
    Aineq_Equal_sum=[Aineq_Equal_sum;constraint_Equal_sum];
    bineq_Equal_sum=[bineq_Equal_sum;ones(T,1)];
end

Aineq_Power_Equal=[];
bineq_Power_Equal=[];

for i=1:size(Power_Equal_matri,1)
    index_row=[];
    constraint_Power_Equal=sparse(T,Total_variable_num);
    index_row=find(Power_Equal_matri(i,:)==1);
    for j=1:length(index_row)
        constraint_Power_Equal(:,state_variable_location(index_row(j),1):...
            state_variable_location(index_row(j),2))=...
            sparse([1:T],[1:T],ones(T,1),T,T);
    end
    Aineq_Power_Equal=[Aineq_Power_Equal;constraint_Power_Equal];
    bineq_Power_Equal=[bineq_Power_Equal;ones(T,1)];
end


Aeq=[Aeq_AlwaysOn_Mode_Operation];%
beq=[beq_AlwaysOn_Mode_Operation];%
Aineq=[Aineq_constraint_difference;Aineq_Single_Mode_Operation;Aineq_Power_Equal;];%;];;Aineq_Equal_sum
bineq=[bineq_constraint_difference;bineq_Single_Mode_Operation;bineq_Power_Equal; ];%;];;bineq_Equal_sum
lb=sparse(Total_variable_num,1);
lb(auxily_var_location)=-inf;
ub=ones(Total_variable_num,1);
ub(auxily_var_location)=inf;
ctype='';
ctype(decision_var_location)='B';
ctype(auxily_var_location)='C';

model.Q=[];
model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;


tic
[result] = solve(model,0.001,TIME);
% [x,fval,exitflag,output] = cplexmilp(f,Aineq,bineq,Aeq,beq,[],[],[],lb,ub,ctype);%,[],options);
x_state=reshape(round(result.x(decision_var_location)),T,N)';
power_state=repmat(appliance_Power_vector,1,T).*x_state;

for i=1:appliance_num
    row_index=find(index_appliance==i);
    appliance_power(i,:)=sum(power_state(row_index,:),1);
    x_state_No(i,:)=sparse(sum(repmat([1:length(row_index)]',1,T).*x_state(row_index,:),1));
 end
x_state_No_next=x_state_No(:,2:end);
%% STD  Correction
for i=1:appliance_num
    if(length(P_feature{i})>1)
        for t=1:T-1
            if(x_state_No(i,t)>0&&x_state_No_next(i,t)>0)
                t
                if(Transition_model{i}(x_state_No(i,t),x_state_No_next(i,t))==0)
                    power_num=[];
                   [index_state]=find(Transition_model{i}(x_state_No(i,t),:)==1);
                   for k=1:length(index_state)
                       appliance_power(i,t+1)=P_feature{i}(index_state(k));
                       power_num(k)=abs(testData(t+1)-sum(appliance_power(:,t+1)));
                   end
                   [index_better]=find(power_num==min(power_num));
               
                   appliance_power(i,t+1)=P_feature{i}(index_state(index_better));
                   x_state_No(i,t+1)=index_state(index_better);
                   
                   row_index=find(index_appliance==i);
                   x_state(row_index,t+1)=0;
                   x_state(row_index(index_state(index_better)),t+1)=1;
                   
                end
            end
        end
    end
end










% Median filter
S = class_num;
x_state_Nrows = ones(appliance_num, T);
p1 = 1;
for i = 1:appliance_num
    if (S(:,i) == 1)
        x_state_Nrows(i, :) = x_state(p1, :);
        p1 = p1+S(1, i);
        continue;
    end
    for j = 1:S(1, i)
        index = find(x_state(p1+j-1, :) == 1);
        x_state_Nrows(i, index) = j;
    end
    p1 = p1+S(1, i);
end


filter_martix = [];
filter_window = [1 5];
for i = 1:appliance_num
    filter_row = medfilt2(x_state_Nrows(i, :), filter_window);
%     filter_row(1, find(filter_row <= 1&filter_row>0)) = 1;
    filter_martix = [filter_martix; filter_row];
    
end
filter_martix = floor(filter_martix);
x_state_filter = zeros(N, T);
p1 = 1;
for i = 1:appliance_num
    if (S(:,i) == 1)
        x_state_filter(p1, :) = filter_martix(i, :);
        p1 = p1+S(1, i);
        continue;
    end
    for j = 1:S(1, i)
        index = find(filter_martix(i, :) == j);
        x_state_filter(p1+j-1, index) = 1;
    end
    p1 = p1+S(1, i);
end

x_state_temp=x_state;

%% LP refinement
r_P=sparse(N,1);

for i=1:N
    if(appliance_Power_vector(i)==appliance_Power_min_vector(i)&&appliance_Power_vector(i)==appliance_Power_max_vector(i))
        r_P(i,1)=1;
        
    else
        r_P(i,1)=2;
    end
end



%object
LP_f=sparse(Total_variable_num,1);
LP_f(auxily_var_location)=1;


%constraint

Aineq_constraint_difference=[];
bineq_constraint_difference=[];
xit=[];
for i=1:N
    x_part=sparse(diag(-1*ones(1,T)));
    xit=[xit,x_part];
end
k_pt=sparse(diag(-1*ones(T,1)));

Aineq_constraint_difference=[Aineq_constraint_difference;xit,k_pt];
bineq_constraint_difference=[bineq_constraint_difference;-1*testData];

%
xit=[];
for i=1:N
    x_part=sparse(diag(ones(1,T)));
    xit=[xit,x_part];
end
k_pt=sparse(diag(-1*ones(T,1)));
Aineq_constraint_difference=[Aineq_constraint_difference;xit,k_pt];
bineq_constraint_difference=[bineq_constraint_difference;testData];

Aineq_power_refine=[];
bineq_power_refine=[];

Aeq_power_refine=[];
beq_power_refine=[];

for i=1:N
    index_row=[];
    location_index=state_variable_location(i,1):state_variable_location(i,2);
    index_row=find(x_state_filter(i,:)==0);
    
    constraint_power_refine=sparse([1:length(index_row)],location_index(index_row),ones(length(index_row),1),length(index_row),Total_variable_num);

    Aeq_power_refine=[Aeq_power_refine;constraint_power_refine];
    beq_power_refine=[beq_power_refine;sparse(length(index_row),1)];

     index_row=find(x_state_filter(i,:)==1);
     constraint_power_refine=sparse([1:length(index_row)],location_index(index_row),ones(length(index_row),1),length(index_row),Total_variable_num);

    if(r_P(i)==1)

        Aeq_power_refine=[Aeq_power_refine;constraint_power_refine];
        beq_power_refine=[beq_power_refine;appliance_Power_vector(i)*ones(length(index_row),1)];
    else

        Aineq_power_refine=[Aineq_power_refine;constraint_power_refine];
        bineq_power_refine=[bineq_power_refine;appliance_Power_max_vector(i)*ones(length(index_row),1)];
        
        Aineq_power_refine=[Aineq_power_refine;-1*constraint_power_refine];
        bineq_power_refine=[bineq_power_refine;-1*appliance_Power_min_vector(i)*ones(length(index_row),1)];
    end
end

Aeq=[Aeq_power_refine];%
beq=[beq_power_refine];%
Aineq=[Aineq_constraint_difference;Aineq_power_refine];%;];
bineq=[bineq_constraint_difference;bineq_power_refine];%;];
lb=sparse(Total_variable_num,1);
lb(auxily_var_location)=-inf;
ub=inf*ones(Total_variable_num,1);
ctype='';
ctype(1:Total_variable_num)='C';

toc 
computation_time=toc;
model=[];
model.Q=[];
model.f=LP_f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;

[results] = solve(model,0.001,TIME-computation_time);
% [x,fval,exitflag,output] = cplexlp(LP_f,Aineq,bineq,Aeq,beq,lb,ub);%,[],options);
x_state=reshape(results.x(decision_var_location),T,N)';
for i=1:appliance_num
    row_index=find(index_appliance==i);
    appliance_power(i,:)=sum(x_state(row_index,:),1);
end


result.x_state=x_state_temp;
result.runtime=computation_time+results.runtime;
result.appliance_power=appliance_power;




model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;
end

