% CSV����Ԥ�����������޹�����
function [P, Q, P_Sum, Transition_model, Omega,probabilities_On,minActiveTime,maxActiveTime,maxUpwardTransition,maxPower,maxPower_peroid] = Easy_dataProcessing(select_device,select_data_type, select_data_Set, S, train_data,test_data,train_data_num,test_data_num,train_day_num,cluster_id,always_On_appliance,State_Limit)
minActiveTime=[];
maxActiveTime=[];
N= length(select_device);
train_rows=train_data_num;
index_appliance=[];
for i=1:N
    index_appliance=[index_appliance;i*ones(S(i),1)];
end
% select_device = {'BME', 'CDE', 'DWE', 'FGE', 'FRE', 'HPE', 'TVE'};

% ��������õ��������ݣ���ȡѵ�����Ͳ��Լ��������й����޹�

P_train = {};
Q_train = {};
P_test = {};
Q_test = {};

for i=1:length(select_data_type)
    switch select_data_type{i}
        case 'P'
            eval(strcat('P_train=','train_data.',select_data_Set{1},'.appliance_P;'));
            eval(strcat('P_test=','test_data.',select_data_Set{1},'.appliance_P;'));
            P_Sum=sum(P_test,2);
        case 'Q'
            eval(strcat('Q_train=','train_data.',select_data_Set{1},'.appliance_Q;'));
            eval(strcat('Q_test=','test_data.',select_data_Set{1},'.appliance_Q;'));
            Q_Sum=sum(Q_test,2);
        otherwise
            warning('no exist this data type!');
    end
end




Remove_Noise_Value = 0.01; %���������ȥ��ǰ��1%��ֵ��Ŀ����Ϊȥ������

State_Size = sum(S);

P = [];
P_top = [];
P_bottom = [];

Q = [];
Q_top = [];
Q_bottom = [];

% State_Limit = inf*ones(X_Size, 1);
P_State = {}; % �õ������������

P_State_origin = {}; % ԭʼ����״̬
P_State_sort_origin = {}; % ԭʼ����״̬����
Q_State_sort_origin = {}; % ԭʼ����״̬����
P_State_unsort_origin = {}; % ԭʼ����״̬����
Q_State_unsort_origin = {}; % ԭʼ����״̬����
% ����kmeans�������״̬�Ĺ���P, P_Top, P_Bottom
noise_rate = 0.02;
for i = 1:N
    result_Idx=cluster_id(:,i);
%     [result_Idx, C, sumD, D] = kmeans(P_train(:,i), S(:, i), 'dist','sqEuclidean','Replicates', 4);
    P_State_origin = [P_State_origin; result_Idx];
    P_temp = [];
    for j = 1:S(:, i)
        P_len = length(P_train(find(result_Idx == j), i));
        P_temp = [P_temp, sum(P_train(find(result_Idx == j), i))/P_len]; % ���㵱ǰ��������ƽ�����ʣ�������ʱ����
    end
    % �ҵ���ϵ��Ӧ��Ŀ���ǰ����ʴ�С����״̬��ֻ���й��������ţ��޹������й������ʶ��
    P_temp_sort = sort(P_temp);
    relation = ones(S(:, i), 1);
    for j = 1:S(:, i)
        value = P_temp(:, j);
        idx = find(P_temp_sort ==value);
        relation(j, :) = idx;
    end
    % ���¸�ֵ
    result_Idx_new = result_Idx;
    for j = 1:S(:, i)
        result_Idx_new(find(result_Idx == j)) = relation(j, :);
    end
    P_State = [P_State; result_Idx_new];
    for j = 1:S(:, i)
        
        len1 = length(P_train(find(result_Idx_new == j), i));
        P = [P; sum(P_train(find(result_Idx_new == j), i))/len1];
        %         P_top = [P_top; max(P_train{i}(find(result_Idx_new == j)))];
        %         P_bottom = [P_bottom; min(P_train{i}(find(result_Idx_new == j)))];
        
        PS_o = sort(P_train(find(result_Idx_new == j), i)); % �����״̬����ֵ��ʹ��³�����Իع��������������
        
        k = floor(len1 * noise_rate);
        P_top = [P_top; max(PS_o)];
        P_bottom = [P_bottom; min(PS_o)];
        P_State_sort_origin = [P_State_sort_origin; PS_o]; % �ϲ�
        P_State_unsort_origin = [P_State_unsort_origin; P_train(find(result_Idx_new == j), i)];
        if(~isempty(Q_train))
            len2 = length(Q_train(find(result_Idx_new == j), i));
            Q = [Q; sum(Q_train(find(result_Idx_new == j), i))/len2];
            QS_o = sort(Q_train(find(result_Idx_new == j), i));
            Q_State_sort_origin = [Q_State_sort_origin; QS_o]; % �ϲ�
            Q_State_unsort_origin = [Q_State_unsort_origin; Q_train(find(result_Idx_new == j), i)];
        end
    end
end


% ���ô���˼��ȥͳ����С����ʱ�䣬���ڵ�Ŀ����ȥ������


UpwardTransition=[];
for l=1:floor(train_data_num/test_data_num)
    cnt  = 0 ;
    State_limit_list = {};
    for i = 1:State_Size
        State_limit_list = [State_limit_list; [0]];
    end
    p1 = 0;
    for i = 1:N
        P_temp = P_State{i}((l-1)*test_data_num+1:l*test_data_num);
        cur_state = P_temp(1,1);
        cur_index = 1;
        for j = 2:length(P_temp)
            if (cur_state ~= P_temp(j, :))
                State_limit_list{p1+cur_state} = [State_limit_list{p1+cur_state}; j-cur_index+1];
                cur_state = P_temp(j, :);
                cur_index = j;
            end
        end
        p1 = p1+S(:, i);
    end

beta ={};
reg_beta = {};
eta = 100;
accuracy = 0.01;
state_limit_large = {};
extend_times = 1;
for i = 1:State_Size
    if(length(State_limit_list{i})>1)
    state_limit_temp = State_limit_list{i}(2:end, :);
    else
        state_limit_temp=1;
    end
    state_limit_large = [state_limit_large; repmat(state_limit_temp, extend_times, 1)];
end
len_num=[];

for i=1:length(state_limit_large)
    len_num=[len_num;length(state_limit_large{i})];
end

UpwardTransition=[UpwardTransition,len_num];
end
maxUpwardTransition=max(UpwardTransition,[],2);
% Ci = lamda * wi�����Ի���Ҫ��wi
maxPower_peroid={};
maxPower=[];
for i = 1:N
    data_power_sum=[];
    maxPower_peroid{i}={[1:round(test_data_num/4)];[2*round(test_data_num/4)+1:3*round(test_data_num/4)]};
    for l=1:floor(train_data_num/test_data_num)
        
        data_power=P_train((l-1)*test_data_num+1:l*test_data_num,i);
        data_power_sum=[data_power_sum;sum(data_power(1:round(test_data_num/4))),sum(data_power(2*round(test_data_num/4)+1:3*round(test_data_num/4)))];
    end
    maxPower=[maxPower;max(data_power_sum,[],1)]
end

% ״̬ת������
Transition_model = {};
W = [];
for i = 1:N
    trans = diag(ones(S(:, i),1)); % ��ʼΪ�ԽǾ��󣬱�ʾͬ״̬���໥ת��
    P_state_temp = P_State{i};
    P_state_next=P_state_temp(2:end);
    state_change_location=find((P_state_next-P_state_temp(1:end-1))~=0)+1;
    for j=1:length(state_change_location)
            p1 =state_change_location(j)-1;
            p2 = state_change_location(j);
            
            index=find(index_appliance==i);
            T_Window_1=State_Limit(index(P_state_temp(p1)));
            T_Window_2=State_Limit(index(P_state_temp(p2)));
            if(p1-T_Window_1>=0&&p2+T_Window_2<=length(P_state_temp))
                window1 = P_state_temp(p1-T_Window_1+1:p1, :);
                window2 = P_state_temp(p2:p2+T_Window_2-1, :);
                if (all (~(diff(window1))) && all (~(diff(window2))))
                    s1 = P_state_temp(p1);
                    s2 = P_state_temp(p2);                   
                    trans(s1, s2) = 1; % ���s1״̬��ת����s2״̬
                else
                    if(all (~(diff(window1)))~=1 && all (~(diff(window2)))~=1)
                        window=[window1;window2];
                        window = medfilt1(window);
                        window1=window(1:length(window1));
                        window2=window(length(window1)+1:end);
                    else
                        if(all (~(diff(window1)))~=1)
                            window1 = medfilt1(window1);
                            
                        end
                        if(all (~(diff(window2)))~=1)
                            window2 = medfilt1(window2);
                        end
                    end
                   s1 = window1(end);
                   s2 = window2(1);
                   trans(s1, s2) = 1; % ���s1״̬��ת����s2״̬
                end
            end
    end

    W = [W; train_rows/length(state_change_location)];
    Transition_model = [Transition_model; trans];
end

Omega =W;
% p1 = 1;
for i = 1:N
%     Omega(p1:p1+S(:, i)-1, :) = W(i, :);
%     p1 = p1+S(:, i);
    state_data_interval=reshape(P_State{i},train_data_num/train_day_num,train_day_num)';
    for t=1:train_data_num/train_day_num
        for j=1:S(i)
            [index_location]=find(state_data_interval(:,t)==j);
            if(length(index_location)==0)
                if(i==1)
                    On_state_num(j,t)=1;
                else
                    On_state_num(sum(S(1:i-1))+j,t)=1;
                end
            else
                if(i==1)
                    On_state_num(j,t)=length(index_location);
                else
                    On_state_num(sum(S(1:i-1))+j,t)=length(index_location);
                end
            end
        end
        if(always_On_appliance(i)==1)
            [index_location]=find(state_data_interval(:,t)>0);
        else
            [index_location]=find(state_data_interval(:,t)>1);
        end
        On_appliance_num(i,t)=length(index_location);
    end
end
probabilities_On=1./On_state_num;
% ��������
end
