function [model,result] = function_new_MF(testData,class_num,P_feature,TIME,D_VFP,State_Limit,State_max_Limit,index_VFP,always_On_appliance)
%FUNCTION_NEW_METHOD �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

beta=10;
gamma=0;

index_flow=[];%[0,0,1,-1,0,0,0];
%% 



P=P_feature; %����
P_Sum=testData;  %�ܹ���
T=length(P_Sum);
S=class_num;



% S=S+alway_on_matri-1;
N = length(S);% �����豸����
state_size = sum(S);

Total_variable_num=0;
%x location
state_variable_location(:,1)=1:T:state_size*T;
state_variable_location(:,2)=[state_variable_location(2:end,1)-1;state_size*T];
state_variable_length=state_size*T;
Total_variable_num=Total_variable_num+state_size*T;



index_appliance=[];
for i=1:N
    index_appliance=[index_appliance;i*ones(S(i),1)];
end


%quadr term

%the sum of squared differences
H=[];
coeff_sum=[];
j=1;
for i=1:state_size
    if(isempty(find(index_VFP==index_appliance(i))))
        coeff_sum=[coeff_sum,sparse(1:T,1:T,P(i)*ones(1,T),T,T)];
    else
        coeff_sum=[coeff_sum,sparse(1:T,1:T,D_VFP(:,j),T,T)];
        j=j+1;
    end
end
H_sq=coeff_sum'*coeff_sum;

f_sq=-2*coeff_sum'*P_Sum;
%penlty term

%sum to k
Q_penlty=[];
for i=1:length(index_VFP)
    Q_penlty_temp=sparse(T,Total_variable_num);
    index_state=find(index_appliance==index_VFP(i));
    for j=1:length(index_state)
        Q_penlty_temp(:,state_variable_location(index_state(j),1):state_variable_location(index_state(j),2))=sparse(1:T,1:T,ones(1,T),T,T);
    end
    Q_penlty=[Q_penlty;Q_penlty_temp];
end

U=ones(size(Q_penlty,1),1);


%flowline
[index_row_positive,index_col_positive]=find(index_flow==1);
[index_row_negtive,index_col_negtive]=find(index_flow==-1);
R_penlty=[];
for i=1:length(index_row_positive)
    for j=1:length(index_col_positive)
        
        index_state_positive=find(index_appliance==index_col_positive(j));
        index_state_negtive=find(index_appliance==index_col_negtive(j));
        for k=1:length(index_state_positive)
            R_penlty_temp=sparse(T,Total_variable_num);
            R_penlty_temp(:,state_variable_location(index_state_positive(k),1):state_variable_location(index_state_positive(k),2))=sparse(1:T,1:T,ones(1,T),T,T);
            R_penlty_temp(:,state_variable_location(index_state_negtive(k),1):state_variable_location(index_state_negtive(k),2))=sparse(1:T,1:T,-1*ones(1,T),T,T);
            R_penlty=[R_penlty;R_penlty_temp];
        end
      end
end


H_penlty=[beta*Q_penlty',-1*gamma*R_penlty']*[beta*Q_penlty;-1*gamma*R_penlty];

f_penlty=-2*[beta*Q_penlty',-1*gamma*R_penlty']*[beta*U;sparse(size(R_penlty,1),1)];

% H_temp=[];
% for i=1:state_size
%     H_temp=[H_temp,sparse([1:T],[1:T],ones(1,T),T,T)];
% end
% for i=1:state_size
%     H=[H;sparse(T,state_variable_length),H_temp,sparse(T,eta_variable_length)];
% end
%
if(isempty(index_flow))
    H=H_sq;
    f=f_sq;
else
 H=H_sq+H_penlty;
f=f_penlty+f_sq;
end

%��С�ʱ��Լ��
Aineq_min_active_time_constraint=[];
bineq_min_active_time_constraint=[];

for i=1:state_size
    if(isempty(find(index_VFP==index_appliance(i))))
        state_vari_location=state_variable_location(i,1):state_variable_location(i,2);
        if(State_Limit(i)>1)
            if(State_Limit(i)>T)
                State_Limit(i)=T;
            end
            for j=1:State_Limit(i)-1
                x_t_1_location_row=1:T-j-1;
                x_t_1_location_col=state_vari_location(1:T-j-1);
                x_t_1_location_value=-1*ones(1,T-j-1);
                
                x_t_location_row=1:T-j-1;
                x_t_location_col=state_vari_location(2:T-j);
                x_t_location_value=ones(1,T-j-1);
                
                x_tao_location_row=1:T-j-1;
                x_tao_location_col=state_vari_location(j+2:T);
                x_tao_location_value=-1*ones(1,T-j-1);
                
                row_location=[x_t_1_location_row,x_t_location_row,x_tao_location_row];
                col_location=[x_t_1_location_col,x_t_location_col,x_tao_location_col];
                coefficient_value=[x_t_1_location_value,x_t_location_value,x_tao_location_value];
                
                constraint_min_active_time=sparse(row_location,col_location,coefficient_value,T-j-1,Total_variable_num);
                Aineq_min_active_time_constraint=[Aineq_min_active_time_constraint;constraint_min_active_time];
            end
        end
    end
end
bineq_min_active_time_constraint=sparse(size(Aineq_min_active_time_constraint,1),1);



%Multiple States Selected Constraints
Aineq_Multiple_States_Selected_Constraints=[];
bineq_Multiple_States_Selected_Constraints=[];

Aeq_Multiple_States_Selected_Constraints=[];
beq_Multiple_States_Selected_Constraints=[];

for i=1:N
    if(isempty(find(index_VFP==i)))
     
            appliance_index=find(index_appliance==i);
            state_location_row=[];
            state_location_col=[];
            for j=1:length(appliance_index)
                state_location_row=[state_location_row,1:T];
                state_location_col=[state_location_col,state_variable_location(appliance_index(j),1):state_variable_location(appliance_index(j),2)];
            end
            Aeq_Multiple_States_Selected_Constraints=[Aeq_Multiple_States_Selected_Constraints;...
                sparse(state_location_row,state_location_col,ones(1,size(state_location_col,2)),T,Total_variable_num)];
            beq_Multiple_States_Selected_Constraints=[beq_Multiple_States_Selected_Constraints;ones(T,1)];


    end
end



Aineq_Max_active_constraint=[];
bineq_Max_active_constraint=[];
maxActiveTime=State_max_Limit;
for i=1:state_size
    
    if(isempty(find(index_VFP==i)))
        %max active constraint
        if(T>maxActiveTime(i))
            max_active_constraint=sparse(T-maxActiveTime(i),Total_variable_num);
            for j=1:maxActiveTime(i)+1
                max_active_constraint(:,state_variable_location(i,1):state_variable_location(i,2))=max_active_constraint(:,state_variable_location(i,1):state_variable_location(i,2))+...
                    sparse([1:T-maxActiveTime(i)],[j:j+T-maxActiveTime(i)-1],ones(1,T-maxActiveTime(i)),T-maxActiveTime(i),T);
            end
            Aineq_Max_active_constraint=[Aineq_Max_active_constraint;max_active_constraint];
            bineq_Max_active_constraint=[bineq_Max_active_constraint;maxActiveTime(i)*ones(T-maxActiveTime(i),1)];
        else
            disp('error:Total time < maxActiveTime');
            break;
        end
    end
end



Aineq=[Aineq_min_active_time_constraint;Aineq_Multiple_States_Selected_Constraints;Aineq_Max_active_constraint];
bineq=[bineq_min_active_time_constraint;bineq_Multiple_States_Selected_Constraints;bineq_Max_active_constraint];

Aeq=[Aeq_Multiple_States_Selected_Constraints];
beq=[beq_Multiple_States_Selected_Constraints];


    ctype = '';
    ub=[];
    for i=1:state_size
        
        if(isempty(find(index_VFP==index_appliance(i))))
            ctype(state_variable_location(i,1):state_variable_location(i,2)) = 'B';
            ub=[ub;ones(T, 1)];
        else
            ctype(state_variable_location(i,1):state_variable_location(i,2)) = 'C';
            ub=[ub;inf*ones(T, 1)];
        end
    end
    lb = sparse(Total_variable_num, 1);
    
    model.Q=H;
    model.f = f;
    model.Aineq = Aineq;
    model.bineq = bineq;
    model.Aeq = Aeq;
    model.beq = beq;
    model.lb=lb;
    model.ub=ub;
    model.ctype=ctype;
     [results] = solve(model,0.005,TIME);
    init_time=results.runtime;
    
x_state=reshape(results.x,T,state_size)';
power_state=repmat(P,1,T).*x_state;
for i=1:N
    row_index=find(index_appliance==i);
    appliance_power(i,:)=sum(power_state(row_index,:),1);
%     appliance_state(i,:)=sum(x_state(row_index,:),1);
end
result.x_state=x_state;
result.appliance_power=appliance_power;
result.runtime=results.runtime;


end

