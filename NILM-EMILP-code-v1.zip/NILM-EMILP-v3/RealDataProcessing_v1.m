% CSV����Ԥ�����������޹�����
function [P, P_top, P_bottom, State_Limit, P_test, P_Sum, P_up, P_down,Transition_model, Omega, P_train] = RealDataProcessing_v1(select_device,select_data_type,select_data_Set, S,  train_data,test_data,train_data_num,test_data_num,train_day_num,cluster_id,always_On_appliance)

N= length(select_device);
train_rows=train_data_num;
index_appliance=[];
for i=1:N
    index_appliance=[index_appliance;i*ones(S(i),1)];
end
% select_device = {'BME', 'CDE', 'DWE', 'FGE', 'FRE', 'HPE', 'TVE'};


% ��������õ��������ݣ���ȡѵ�����Ͳ��Լ��������й����޹�
P_train = {};
Q_train = {};
P_test = {};
Q_test = {};

for i=1:length(select_data_type)
    switch select_data_type{i}
        case 'P'
            eval(strcat('P_train=','train_data.',select_data_Set{1},'.appliance_P;'));
            eval(strcat('P_test=','test_data.',select_data_Set{1},'.appliance_P;'));
            P_Sum=sum(P_test,2);
        case 'Q'
            eval(strcat('Q_train=','train_data.',select_data_Set{1},'.appliance_Q;'));
            eval(strcat('Q_test=','test_data.',select_data_Set{1},'.appliance_Q;'));
            Q_Sum=sum(Q_test,2);
        otherwise
            warning('no exist this data type!');
    end
end



State_Size = sum(S);

P = [];
P_top = [];
P_bottom = [];

% Q = [];
% Q_top = [];
% Q_bottom = [];

% State_Limit = inf*ones(X_Size, 1); 
State_Limit = []; %����״̬����С����ʱ��
P_State = {}; % �õ������������

P_State_origin = {}; % ԭʼ����״̬
P_State_sort_origin = {}; % ԭʼ����״̬����
% Q_State_sort_origin = {}; % ԭʼ����״̬����
P_State_unsort_origin = {}; % ԭʼ����״̬����
% Q_State_unsort_origin = {}; % ԭʼ����״̬����
% ����kmeans�������״̬�Ĺ���P, P_Top, P_Bottom

for i = 1:N
    result_Idx=cluster_id(:,i);
%     [result_Idx, C, sumD, D] = kmeans(P_train{i}, S(:, i), 'dist','sqEuclidean','Replicates', 4);
    P_State_origin = [P_State_origin; result_Idx];
    P_temp = [];
    for j = 1:S(:, i)
        P_len = length(P_train(find(result_Idx == j), i));
        P_temp = [P_temp, sum(P_train(find(result_Idx == j), i))/P_len]; % ���㵱ǰ��������ƽ�����ʣ�������ʱ����
    end
    % �ҵ���ϵ��Ӧ��Ŀ���ǰ����ʴ�С����״̬��ֻ���й��������ţ��޹������й������ʶ��
    P_temp_sort = sort(P_temp);
    relation = ones(S(:, i), 1);
    for j = 1:S(:, i)
        value = P_temp(:, j);
        idx = find(P_temp_sort ==value);
        relation(j, :) = idx;
    end
    % ���¸�ֵ
    result_Idx_new = result_Idx;
    for j = 1:S(:, i)
        result_Idx_new(find(result_Idx == j)) = relation(j, :); 
    end
    P_State = [P_State; result_Idx_new];
    for j = 1:S(:, i)
%         len = length(P_train{i}(find(result_Idx_new == j), 1));
%         P = [P; sum(P_train{i}(find(result_Idx_new == j), 1))/len];
        PS_o = sort(P_train(find(result_Idx_new == j), i)); % �����״̬����ֵ��ʹ��³�����Իع��������������
%         QS_o = sort(Q_train{i}(find(result_Idx_new == j), 1));
        P_State_sort_origin = [P_State_sort_origin; PS_o]; % �ϲ�
%         Q_State_sort_origin = [Q_State_sort_origin; QS_o]; % �ϲ�
        P_State_unsort_origin = [P_State_unsort_origin; P_train(find(result_Idx_new == j), i)];
%         Q_State_unsort_origin = [Q_State_unsort_origin; Q_train{i}(find(result_Idx_new == j), 1)];
    end
end

% ³���ع�
eta = 0.5;
for i = 1:State_Size
%     [ P_beta ] = function_DRO_LR( [ones(1, length(P_State_sort_origin{i})); [1:length(P_State_sort_origin{i})]], P_State_sort_origin{i}, eta);
% %     [ Q_beta ] = function_DRO_LR( [ones(1, length(Q_State_sort_origin{i})); [1:length(Q_State_sort_origin{i})]], Q_State_sort_origin{i}, eta);
%     P_len = length(P_State_sort_origin{i});
%     Q_len = length(Q_State_sort_origin{i});
    
    P_min = min(P_State_sort_origin{i});
    P_max = max(P_State_sort_origin{i});
    if (P_min < 0)
        P_min = 0;
    end
    if (P_max < 0)
        P_max = 0;
    end
    P_bottom = [P_bottom; P_min];
    P_top = [P_top; P_max];
    P = [P; (P_max+P_min)/2];
    
%     Q_min = Q_beta(1, :)+0*Q_beta(2, :);
%     Q_max = Q_beta(1, :)+Q_len*Q_beta(2, :);
%     if (Q_min < 0)
%         Q_min = 0;
%     end
%     if (Q_max < 0)
%         Q_max = 0;
%     end
%     Q_bottom = [Q_bottom; Q_min];
%     Q_top = [Q_top; Q_max];
%     Q = [Q; (Q_max+Q_min)/2];
end


% ���ô���˼��ȥͳ����С����ʱ�䣬���ڵ�Ŀ����ȥ������
cnt  = 0 ;

AC_Rate = 0.8;
State_limit_list = {};
for i = 1:State_Size
    State_limit_list = [State_limit_list; [0]];
end
p1 = 0;
for i = 1:N
    P_temp = P_State{i};
    cur_state = P_temp(1,1);
    cur_index = 1;
    for j = 2:length(P_temp)
        if (cur_state ~= P_temp(j, :))
            State_limit_list{p1+cur_state} = [State_limit_list{p1+cur_state}; j-cur_index+1];
            cur_state = P_temp(j, :);
            cur_index = j;
        end
    end
    p1 = p1+S(:, i);
end
beta ={};
reg_beta = {};
eta = 0.5;
accuracy = 0.01;
state_limit_large = {};
extend_times = 1;
for i = 1:State_Size
    state_limit_temp = State_limit_list{i}(2:end, :);
    state_limit_large = [state_limit_large; repmat(state_limit_temp, extend_times, 1)];
end

state_limit_new_list = {};
for i = 1:State_Size
%     state_limit_temp = State_limit_list{i}(2:end, :);
%     state_limit_temp = sort(state_limit_temp);
if(max(state_limit_large{i})>=test_data_num)
    index_MAX=find(state_limit_large{i}>=test_data_num);
    state_limit_large{i}(index_MAX)=test_data_num-2;
end
    state_limit_temp = state_limit_large{i};
    state_limit_temp = sort(state_limit_temp);
     [ state_beta1 ] = function_DRO_LR_fixB( [ones(1, length(state_limit_temp)); [1:length(state_limit_temp)]], state_limit_temp, eta, min(state_limit_temp));
     max_value = length(state_limit_temp)*state_beta1(2,:)+state_beta1(1,:);
     state_limit_new = state_limit_temp(find(state_limit_temp<=max_value));
     state_limit_new_list = [state_limit_new_list; state_limit_new];
%      [ state_beta2 ] = function_DRO_LR( [ones(1, length(state_limit_new)); [1:length(state_limit_new)]], state_limit_new, eta);
%     [b,bint,r,rint,stats] = regress(state_limit_temp, [ones(1, length(state_limit_temp)); [1:length(state_limit_temp)]]');
%     [ state_beta ] = function_DRO_LR( [ones(1, length(state_limit_temp)); [1:length(state_limit_temp)]], state_limit_temp, eta);
    [ state_beta ] =DRO_v1(state_limit_new, accuracy, eta);
%     reg_beta = [reg_beta; b];
    beta = [beta; state_beta];
    state_min = state_beta(1, :)+0*state_beta(2, :);
    if (state_min <= 0)
        state_min =  min(state_limit_new);
    end
    State_Limit = [State_Limit; round(state_min)];

end
State_Limit(State_Limit==0)=1;
disp('State_Limit done!');

% for i = 1:N
%     P_temp = P_State{i};
%     for j = 1:S(:, i)
%          state_length = 0;
%         for t = 1:train_rows-T_Window
%             if (length(find(P_temp(t:t+T_Window, :) == j)) >=T_Window*AC_Rate)
%                 state_length = state_length+1;
%             else
%                 % �˴������豸��һ��״̬���ж�֮ǰͳ�Ƶ�״̬����ʱ���Ƿ�С��֮ǰͳ�Ƶ���С����ʱ��
%                 if (state_length < State_Limit(cnt+j, :) && state_length>1)
%                     State_Limit(cnt+j, :) = state_length+T_Window*AC_Rate;
%                 end
%                 state_length = 0; % ��0����ͳ��
%             end
%         end
%     end
%     cnt  = cnt + S(:, i);
% end
% State_Limit = floor(State_Limit);
% for i = 1:X_Size
%     State_Limit(i,:) = State_Limit(i,:)+30;
% end
% �����豸��ͬ״̬����л��仯����
% P_transition = {};
% cnt = 1;
% for i = 1:N
%     state_transtion = zeros(S(:, i), S(:, i));
%     p_state_temp = P(cnt:cnt+S(:, i)-1, :);
%     for s1 = 1:S(:, i)
%         for s2 = 1:S(:, i)
%             state_transtion(s1, s2) = abs(p_state_temp(s1, :) - p_state_temp(s2, :));
%         end
%     end
%     P_transition = [P_transition; state_transtion];
%     cnt = cnt + S(:, i);
% end

% �����豸��ͬ״̬��ı仯�������ֵ����Сֵ
P_up = [];
P_down = [];
% Q_up = [];
% Q_down = [];
P_up_list ={};
% Q_up_list ={};
P_down_list ={};
% Q_down_list ={};
Remove_Noise_Value = 0.01;
for i = 1:N
    P_train_temp = P_train(:,i);
    P_state_temp = P_State{i};
%     Q_train_temp = Q_train{i};
%     Q_state_temp = P_State{i}; % �޹���״̬���й�Ϊ׼
%     P_positive_value = [];
%     P_negative_value = [];
%     Q_positive_value = [];
%     Q_negative_value = [];
    for j = 1:S(:, i)
        P_state_j = P_train_temp(find(P_state_temp == j), :);
%         Q_state_j = Q_train_temp(find(Q_state_temp == j), :);
        P_state_j_sub = [[P_state_j; 0] - [0; P_state_j]];
%         Q_state_j_sub = [[Q_state_j; 0] - [0; Q_state_j]];
        P_positive_value = P_state_j_sub(find(P_state_j_sub>0));
        P_negative_value = P_state_j_sub(find(P_state_j_sub<0));
%         Q_positive_value = Q_state_j_sub(find(Q_state_j_sub>0));
%         Q_negative_value = Q_state_j_sub(find(Q_state_j_sub<0));
%         for t = 2:length(P_state_j)
%             D_value_P = P_state_j(t, :) - P_state_j(t-1, :);
%             D_value_Q = Q_state_j(t, :) - Q_state_j(t-1, :);
%             if (D_value_P > 0)
%                 P_positive_value = [P_positive_value; D_value_P];
%             elseif (D_value_P < 0)
%                 P_negative_value = [P_negative_value; D_value_P];
%             else
%             end
%             if (D_value_Q > 0)
%                 Q_positive_value = [Q_positive_value; D_value_Q];
%             elseif (D_value_Q < 0)
%                 Q_negative_value = [Q_negative_value; D_value_Q];
%             else
%             end
%         end
        P_sort_positive = sort(P_positive_value(:, 1));
        P_sort_negative = sort(abs(P_negative_value(:, 1)));
%         Q_sort_positive = sort(Q_positive_value(:, 1));
%         Q_sort_negative = sort(abs(Q_negative_value(:, 1)));
        P_up_list = [P_up_list; P_sort_positive];
%         Q_up_list = [Q_up_list; Q_sort_positive];
        P_down_list = [P_down_list; P_sort_negative];
%         Q_down_list = [Q_down_list; Q_sort_negative];
        
         
         [ P_up_beta ] = function_DRO_LR( [ones(1, length(P_sort_positive)); [1:length(P_sort_positive)]], P_sort_positive, eta);
         [ P_down_beta ] = function_DRO_LR( [ones(1, length(P_sort_negative)); [1:length(P_sort_negative)]], P_sort_negative, eta);
%          [ Q_up_beta ] = function_DRO_LR( [ones(1, length(Q_sort_positive)); [1:length(Q_sort_positive)]], Q_sort_positive, eta);
%          [ Q_down_beta ] = function_DRO_LR( [ones(1, length(Q_sort_negative)); [1:length(Q_sort_negative)]], Q_sort_negative, eta);
         
         P_up_max = P_up_beta(1, :)+length(P_sort_positive)*P_up_beta(2, :);
         P_down_max = P_down_beta(1, :)+length(P_sort_negative)*P_down_beta(2, :);
%          Q_up_max = Q_up_beta(1, :)+length(Q_sort_positive)*Q_up_beta(2, :);
%          Q_down_max = Q_down_beta(1, :)+length(Q_sort_negative)*Q_down_beta(2, :);
         P_up = [P_up; P_up_max];
         P_down = [P_down; P_down_max]; 
%          Q_up = [Q_up; Q_up_max];
%          Q_down = [Q_down; Q_down_max];
%         P_k_positive = ceil(length(P_sort_positive) * Remove_Noise_Value);
%         P_k_negative = ceil(length(P_sort_negative) * Remove_Noise_Value);
%         P_up = [P_up; P_sort_positive(end-P_k_positive)];
%         P_down = [P_down; P_sort_negative(end-P_k_negative)]; 
%         
%         Q_k_positive = ceil(length(Q_sort_positive) * Remove_Noise_Value);
%         Q_k_negative = ceil(length(Q_sort_negative) * Remove_Noise_Value);
%         Q_up = [Q_up; Q_sort_positive(end-Q_k_positive)];
%         Q_down = [Q_down; Q_sort_negative(end-Q_k_negative)];
    end
    
end

P_up = ceil(P_up);
P_down = ceil(P_down);
% Q_up = ceil(Q_up);
% Q_down = ceil(Q_down);

% Ci = lamda * wi�����Ի���Ҫ��wi

% ״̬ת������
Transition_model = {};
W = [];
for i = 1:N
    trans = diag(ones(S(:, i),1)); % ��ʼΪ�ԽǾ��󣬱�ʾͬ״̬���໥ת��
    P_state_temp = P_State{i};
    P_state_next=P_state_temp(2:end);
    state_change_location=find((P_state_next-P_state_temp(1:end-1))~=0)+1;
    for j=1:length(state_change_location)
            p1 =state_change_location(j)-1;
            p2 = state_change_location(j);
            
            index=find(index_appliance==i);
            T_Window_1=State_Limit(index(P_state_temp(p1)));
            T_Window_2=State_Limit(index(P_state_temp(p2)));
            if(p1-T_Window_1>=0&&p2+T_Window_2<=length(P_state_temp))
                window1 = P_state_temp(p1-T_Window_1+1:p1,:);
                window2 = P_state_temp(p2:p2+T_Window_2-1,:);
                if (all (~(diff(window1))) && all (~(diff(window2))))
                    s1 = P_state_temp(p1);
                    s2 = P_state_temp(p2);                   
                    trans(s1, s2) = 1; % ���s1״̬��ת����s2״̬
                else
                    if(all (~(diff(window1)))~=1 && all (~(diff(window2)))~=1)
                        window=[window1;window2];
                        window = medfilt1(window);
                        window1=window(1:length(window1));
                        window2=window(length(window1)+1:end);
                    else
                        if(all (~(diff(window1)))~=1)
                            window1 = medfilt1(window1);
                            
                        end
                        if(all (~(diff(window2)))~=1)
                            window2 = medfilt1(window2);
                        end
                    end
                   s1 = window1(end);
                   s2 = window2(1);
                   j
                   trans(s1, s2) = 1; % ���s1״̬��ת����s2״̬
                end
            end
    end

    W = [W; train_rows/length(state_change_location)];
    Transition_model = [Transition_model; trans];
end
% Transition_model = {};
% T_Window = 3;
% W = [];
% for i = 1:N
%     P_state_temp = P_State{i};
%     p1 =1;
%     p2 = p1+T_Window;
%     trans = diag(ones(S(:, i),1)); % ��ʼΪ�ԽǾ��󣬱�ʾͬ״̬���໥ת��
%     r = 1;
%     while (p2 < train_rows-T_Window)
%         window1 = P_state_temp(p1:p1+T_Window-1, :);
%         window2 = P_state_temp(p2:p2+T_Window-1, :);
%         if (all (~(diff(window1))) && all (~(diff(window2)))) % �жϴ���Ԫ���Ƿ�ȫ����ͬ
%             s1 = window1(1,1); 
%             s2 = window2(1,1);
%             if (s1 ~= s2)
%                 trans(s1, s2) = 1; % ���s1״̬��ת����s2״̬
%                 r = r+1;
%             end
%         end
%         p1 = p1+1;
%         p2 = p2+1;
%     end
%     W = [W; train_rows/r];
%     Transition_model = [Transition_model; trans];
% end
State_Limit = ceil(State_Limit);


Omega = zeros(State_Size, 1);
p1 = 1;
for i = 1:N
    Omega(p1:p1+S(:, i)-1, :) = W(i, :);
    p1 = p1+S(:, i);
end

% ��������
end
