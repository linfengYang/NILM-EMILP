function [model,result] = function_construct_CO(testData,class_num,P_feature,TIME)
%FUNCTION_CONSTRUCT_CO �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
N=sum(class_num);
appliance_num=length(class_num);
T=length(testData);
Total_variable_num=N*T;
variable_num=[0,class_num*T];
state_variable_location(:,1)=1:T:Total_variable_num;
state_variable_location(:,2)=[state_variable_location(2:end,1)-1;Total_variable_num];
for i=2:length(variable_num)
    appliance_variable_location(i-1,1)=sum(variable_num(1:i-1))+1;
    appliance_variable_location(i-1,2)=sum(variable_num(1:i));
end

index_appliance=[];
for i=1:appliance_num
    index_appliance=[index_appliance;i*ones(class_num(i),1)];
end

decision_var_location=1:Total_variable_num;

auxily_var_location=Total_variable_num+1:Total_variable_num+T;


Total_variable_num=Total_variable_num+length(auxily_var_location);%��������

appliance_Power_vector=[];

for i=1:length(P_feature)
    appliance_Power_vector=[appliance_Power_vector;P_feature{i}];
end

%% Ŀ�꺯��
f=sparse(Total_variable_num,1);
f(auxily_var_location)=1;


%Լ��
Aineq_constraint_difference=[];
bineq_constraint_difference=[];
xit=[];
for i=1:N
    x_part=sparse(diag(-1*appliance_Power_vector(i)*ones(1,T)));
    xit=[xit,x_part];
end
k_pt=sparse(diag(-1*ones(T,1)));

Aineq_constraint_difference=[Aineq_constraint_difference;xit,k_pt];
bineq_constraint_difference=[bineq_constraint_difference;-1*testData];

%
xit=[];
for i=1:N
    x_part=sparse(diag(appliance_Power_vector(i)*ones(1,T)));
    xit=[xit,x_part];
end
k_pt=sparse(diag(-1*ones(T,1)));
Aineq_constraint_difference=[Aineq_constraint_difference;xit,k_pt];
bineq_constraint_difference=[bineq_constraint_difference;testData];

Aeq=[];
beq=[];
Aineq=[Aineq_constraint_difference];
bineq=[bineq_constraint_difference];
lb=sparse(Total_variable_num,1);
lb(auxily_var_location)=-inf;
ub=ones(Total_variable_num,1);
ub(auxily_var_location)=inf;
ctype='';
ctype(decision_var_location)='B';
ctype(auxily_var_location)='C';


model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;

[results] = solve(model,0.001,TIME);
% [x,fval,exitflag,output] = cplexmilp(f,Aineq,bineq,Aeq,beq,[],[],[],lb,ub,ctype);%,[],options);
x_state=reshape(results.x(decision_var_location),T,N)';
power_state=repmat(appliance_Power_vector,1,T).*x_state;
for i=1:appliance_num
    row_index=find(index_appliance==i);
    appliance_power(i,:)=sum(power_state(row_index,:),1);
%     appliance_state(i,:)=sum(x_state(row_index,:),1);
end
result.x_state=x_state;
result.appliance_power=appliance_power;
result.runtime=results.runtime;




end

