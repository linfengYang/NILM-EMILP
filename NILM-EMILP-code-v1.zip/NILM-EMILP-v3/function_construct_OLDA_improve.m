function [model,result] = function_construct_OLDA_improve(testData,class_num,state_change_matr,P_feature,penlty_l,u,TIME)
%FUNCTION_CONSTRUCT_OLDA �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
N=sum(class_num);
appliance_num=length(class_num);
T=length(testData);
Total_variable_num=N*T;
variable_num=[0,class_num*T];
state_variable_location(:,1)=1:T:Total_variable_num;
state_variable_location(:,2)=[state_variable_location(2:end,1)-1;Total_variable_num];
for i=2:length(variable_num)
    appliance_variable_location(i-1,1)=sum(variable_num(1:i-1))+1;
    appliance_variable_location(i-1,2)=sum(variable_num(1:i));
end

index_appliance=[];
for i=1:appliance_num
    index_appliance=[index_appliance;i*ones(class_num(i),1)];
end

decision_var_location=1:Total_variable_num;

auxily_var_location=Total_variable_num+1:Total_variable_num+appliance_num*(T-1);


Total_variable_num=Total_variable_num+length(auxily_var_location);%��������
%% Ŀ�꺯��

%������


Q_nonDiag=sparse(Total_variable_num,Total_variable_num);
for i=1:N-1
    Q_other=sparse(Total_variable_num,Total_variable_num);
    Q_other(1:(N-i)*T,i*T+1:N*T)=sparse([1:(N-i)*T],[1:(N-i)*T],ones((N-i)*T,1),(N-i)*T,(N-i)*T);
    Q_nonDiag=Q_other+Q_nonDiag;
end
appliance_Power_vector=[];
P_feature_verctor=sparse(Total_variable_num,1);
for i=1:length(P_feature)
    P_feature_verctor(appliance_variable_location(i,1):appliance_variable_location(i,2))=...
        reshape(repmat(P_feature{i},1,T)',length(P_feature{i})*T,1);
    appliance_Power_vector=[appliance_Power_vector;P_feature{i}];
end

% for i=1:appliance_num
%     [row_temp,col_temp,value_temp]=find(Q_nonDiag(appliance_variable_location(i,1):appliance_variable_location(i,2),:)~=0);
%     Q_nonDiag(appliance_variable_location(i,1):appliance_variable_location(i,2),decision_var_location)=...
%         sparse(row_temp,col_temp,value_temp.*(P_feature_verctor(row_temp).*P_feature_verctor(col_temp)),length([appliance_variable_location(i,1):appliance_variable_location(i,2)]),length(decision_var_location));
% end

for i=1:length(decision_var_location)
    Q_nonDiag(:,i)=Q_nonDiag(:,i).*P_feature_verctor;
end

for i=1:length(decision_var_location)
    Q_nonDiag(i,:)=Q_nonDiag(i,:).*P_feature_verctor';
end

Q_diag=sparse([1:Total_variable_num],[1:Total_variable_num],P_feature_verctor.^2,Total_variable_num,Total_variable_num);

Q=Q_nonDiag+Q_nonDiag'+Q_diag;

%һ����
f=sparse(Total_variable_num,1);
f(decision_var_location)=-2*reshape(repmat(testData,1,N),length(decision_var_location),1).*...
    P_feature_verctor(decision_var_location);
f(auxily_var_location)=u*reshape(repmat(penlty_l,T-1,1),length(auxily_var_location),1);

%% Լ��

%Single_Mode_Operation
Aeq_Single_Mode_Operation=[];
beq_Single_Mode_Operation=[];

for i=1:appliance_num
    
    constraint_Single_Mode_Operation=sparse(T,Total_variable_num);
    location_vector=find(index_appliance==i);
    for j=1:class_num(i)
        
        constraint_Single_Mode_Operation(:,...
            state_variable_location(location_vector(j),1):...
            state_variable_location(location_vector(j),2))=...
            sparse([1:T],[1:T],ones(T,1),T,T);
    end
    Aeq_Single_Mode_Operation=[Aeq_Single_Mode_Operation;constraint_Single_Mode_Operation];
    beq_Single_Mode_Operation=[beq_Single_Mode_Operation;ones(T,1)];
end

%Mode Transition

Aineq_constraint_state_transition=[];
bineq_constraint_state_transition=[];

for i=1:appliance_num
   [row_index,col_index]=find(state_change_matr{i}==0);
   if(~isempty(row_index))
       appliance_index=find(index_appliance==i);
       
       state_location_col=state_variable_location(appliance_index(row_index),1):state_variable_location(appliance_index(row_index),2)-1;
       constraint_state_transition=sparse([1:T-1],state_location_col,ones(1,T-1),T-1,Total_variable_num);
       
       state_location_col=state_variable_location(appliance_index(col_index),1)+1:state_variable_location(appliance_index(col_index),2);
       constraint_state_transition=constraint_state_transition+sparse([1:T-1],state_location_col,ones(1,T-1),T-1,Total_variable_num);
       Aineq_constraint_state_transition=[Aineq_constraint_state_transition;constraint_state_transition];
       bineq_constraint_state_transition=[bineq_constraint_state_transition;ones(T-1,1)];
   end
end

% Qc_Mode_Transition={};
% l_Mode_Transition=[];
% r_Mode_Transition=[];
% 
% location_vector=[];
% 
% Constraint_Qc=sparse(Total_variable_num,Total_variable_num);
% 
% for i=1:appliance_num
%     location_vector=find(index_appliance==i);
%     for j=1:length(location_vector)
%         for k=1:length(location_vector)
%             if(state_change_matr{i}(j,k)==1)
%                 Constraint_Qc(state_variable_location(location_vector(j),1):state_variable_location(location_vector(j),2),...
%                     state_variable_location(location_vector(k),1):state_variable_location(location_vector(k),2))=...
%                     [sparse(T,1),[sparse([1:T-1],[1:T-1],ones(T-1,1),T-1,T-1);sparse(1,T-1)]];
%             end
%             if(state_change_matr{i}(j,k)==0)
%                 Constraint_Qc(state_variable_location(location_vector(j),1):state_variable_location(location_vector(j),2),...
%                     state_variable_location(location_vector(k),1):state_variable_location(location_vector(k),2))=...
%                     [sparse(T,1),[sparse([1:T-1],[1:T-1],-1*ones(T-1,1),T-1,T-1);sparse(1,T-1)]];
%             end
%         end
%     end
% end
% [row_allow_transition,col_allow_transition]=find(Constraint_Qc==1);
% [row_noallow_transition,col_noallow_transition]=find(Constraint_Qc==-1);
% for i=1:length(row_allow_transition)
%     Qc_Mode_Transition{i}=sparse(row_allow_transition(i),col_allow_transition(i),0.5,Total_variable_num,Total_variable_num)+...
%         sparse(row_allow_transition(i),col_allow_transition(i),0.5,Total_variable_num,Total_variable_num)';
% end
% 
% for i=length(row_allow_transition)+1:length(row_allow_transition)+length(row_noallow_transition)
%      Qc_Mode_Transition{i}=sparse(row_noallow_transition(i-length(row_allow_transition)),col_noallow_transition(i-length(row_allow_transition)),0.5,Total_variable_num,Total_variable_num)+...
%          sparse(row_noallow_transition(i-length(row_allow_transition)),col_noallow_transition(i-length(row_allow_transition)),0.5,Total_variable_num,Total_variable_num)';
% end
% l_Mode_Transition=sparse(Total_variable_num,length(row_allow_transition)+length(row_noallow_transition));
% r_Mode_Transition=[ones(length(row_allow_transition),1);sparse(length(row_noallow_transition),1)];

%Auxily constraint
Aineq_Auxily_constraint=[];
bineq_Auxily_constraint=[];

for i=1:N
constraint_Auxily_constraint=sparse(T-1,Total_variable_num);
constraint_Auxily_constraint(:,state_variable_location(i,1):state_variable_location(i,2))=...
    [sparse(T-1,1),sparse([1:T-1],[1:T-1],ones(T-1,1),T-1,T-1)]+...
    [sparse([1:T-1],[1:T-1],-1*ones(T-1,1),T-1,T-1),sparse(T-1,1)];
constraint_Auxily_constraint(:,...
    length(decision_var_location)+(index_appliance(i)-1)*(T-1)+1:...
    length(decision_var_location)+index_appliance(i)*(T-1))=...
    sparse([1:T-1],[1:T-1],-1*ones(T-1,1),T-1,T-1);

Aineq_Auxily_constraint=[Aineq_Auxily_constraint;constraint_Auxily_constraint];

end
bineq_Auxily_constraint=sparse(size(Aineq_Auxily_constraint,1),1);



Aeq=[Aeq_Single_Mode_Operation];
beq=[beq_Single_Mode_Operation];
Aineq=[Aineq_Auxily_constraint];
bineq=[bineq_Auxily_constraint];
lb=sparse(Total_variable_num,1);
lb(auxily_var_location)=-inf;
ub=ones(Total_variable_num,1);
ub(auxily_var_location)=inf;
ctype='';
ctype(decision_var_location)='B';
ctype(auxily_var_location)='C';
H=[];
l=[];
r=[];


model.Q=Q;
model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.Qc=H;
model.l=l;
model.r=r;
model.ctype=ctype;

% options = cplexoptimset;
% options.Display='on';
% options.mip.tolerances.mipgap=3e-5;
% options.timelimit=1000;

[results] = solve(model,0.001,TIME);
% [x,fval,exitflag,output] = cplexmiqp(2*Q,f,Aineq,bineq,Aeq,beq,[],[],[],lb,ub,ctype,[0;1;1;0]);%,[],options);
% [x,result,exitflag,output]=cplexmiqcp(2*Q, f, Aineq, bineq, Aeq, beq, l, H, r, [], [], [], lb, ub, ctype);%, [], option);
x_state=reshape(results.x(decision_var_location),T,N)';
power_state=repmat(appliance_Power_vector,1,T).*x_state;
for i=1:appliance_num
    row_index=find(index_appliance==i);
    appliance_power(i,:)=sum(power_state(row_index,:),1);
end
result.x_state=x_state;
result.appliance_power=appliance_power;
result.runtime=results.runtime;
% [result]=solver_cplex(model);

end


