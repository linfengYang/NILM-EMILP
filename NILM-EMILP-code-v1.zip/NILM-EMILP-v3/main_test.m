
clear all;
All_appliance_name={'fan','hairdryer','kettle','light'};%,'Computer','Television Site','Microwave','Kettle'

data_Folder_Path='data\';
data_Set={'test'};
data_type{1}={'P'};% P is active power  Q is reactive power
data_type{3}={'CLEAN_House1','CLEAN_House2','CLEAN_House3','CLEAN_House4','CLEAN_House5',...
    'CLEAN_House6','CLEAN_House7','CLEAN_House8','CLEAN_House9','CLEAN_House10',...
    'CLEAN_House11','CLEAN_House12','CLEAN_House13','CLEAN_House15',...
    'CLEAN_House16','CLEAN_House17','CLEAN_House18','CLEAN_House19','CLEAN_House20','CLEAN_House21'};

load('E:\matlabworkplace\����ϵͳģ��\NILM\NILM-EMILP\data\REFIT\appliance_information.mat');



select_data_Set=data_Set;
select_data_type=3;%house


select_data_power=data_type{1};
select_data_type_name={'test_data'};

select_appliance_name={{'fan'},{'hairdryer'},{'kettle'},{'light'},{'Refrigerator'},{'Television'},{'Washing Machine'}};
%{,{'Dishwasher'},{'Kettle'}};
%AMPDS {'CDE', 'FRE', 'DWE', 'HPE','RSE','B1E'}
%{'CDE', 'FRE', 'DWE', 'HPE'};
TIME=10000;
cluter_phas=0;
train_day_num=1;
test_day_num=1;
train_data_num=17280;
test_data_num=17280;
train_data_start_location = 1; % ѵ������������ʼ��
partition_index=1;

SO_result=[];
CO_state=[];
SO_state=[];
OLDA_state=[];
ALIP_state=[];
BQP_state=[];
CO_power=[];
SO_power=[];
OLDA_power=[];
ALIP_power=[];
BQP_power=[];
EMILP_state=[];
EMILP_power=[];
EMILP_result=[];
AC=[];
OCC=[];
time=[];
origin_cluster=[];
for partition_index=1:6
test_data_start_location = (train_data_start_location+test_data_num*(partition_index-1)+1)*ones(length(select_appliance_name),1);

[Total_data,train_data,test_data,appliance_location,S,always_On_appliance] = function_read_data(data_Folder_Path,select_data_Set,select_data_type_name,select_appliance_name,...
    train_data_num,test_data_num,train_data_start_location,test_data_start_location);
 


cluster_id=[];
for i=1:length(select_appliance_name)

    switch(select_data_Set{1})
        case 'AMPDS'
            eval(strcat('input_data=','[[1:size(train_data.',select_data_Set{1},'.appliance_',select_data_type{1},',1)]'',','train_data.',select_data_Set{1},'.appliance_',select_data_type{1},'(:,i)];'));
        case 'test'
            eval(strcat('input_data=','[[1:size(train_data.',select_data_Set{1},'.','appliance_P',',1)]'',','train_data.',select_data_Set{1},'.','appliance_P','(:,i)];'));
%             eval(strcat('input_data=','[[1:size(test_data.',select_data_Set{1},'.','appliance_P',',1)]'',','test_data.',select_data_Set{1},'.','appliance_P','(:,i)];'));
%         input_data=[[1:size(Total_data.test.test_data,1)]',Total_data.test.test_data(:,i)];
        case 'REFIT'
            eval(strcat('input_data=','[[1:size(train_data.',select_data_Set{1},'.','appliance_P',',1)]'',','train_data.',select_data_Set{1},'.','appliance_P','(:,i)];'));
    end
    if(cluter_phas==1)
        [result_Idx]=function_getStateNumByKmean(input_data(:,2),select_appliance_name{i},i,0); %%if want to use elbow rule ,change '-1' to 'i'
    else
        [result_Idx]=function_getStateNumByKmean(input_data(:,2),select_appliance_name{i},-1,S(i));
    end
    cluster_id=[cluster_id,result_Idx];
end
origin_cluster=[origin_cluster;cluster_id];
N = length(S); % �����豸����
state_size = sum(S);
T=test_data_num;


%% EMILP

[P, P_top, P_bottom, Q, Q_top, Q_bottom, State_Limit, P_test, Q_test, P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega, P_train,penlty_s,penlty_l,State_max_Limit] = DataProcessing_EMILP(train_data,test_data,select_appliance_name,select_data_power,select_data_Set,S,cluster_id,train_data_num,test_data_num,train_day_num,always_On_appliance);
% P_top(12)=0;
% P_top(11)=0;
% P_bottom(12)=93;
% P_bottom(11)=0;
P_test=num2cell(P_test,1);
disp('data processing Done!');

% validate_day_num=1;
% validate_data_num=600;
% validate_data_location=1:600;
% [C_sart,C_run]=function_grid_search(P_top, P_bottom, Q_top, Q_bottom, State_Limit , train_data.test.appliance_P, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega,validate_data_num,S,validate_day_num,validate_data_location,select_appliance_name,penlty_s,penlty_l,state_size,validate_data_num,N,10,10,10,4,always_On_appliance);
%  C_start=1.0796; %house 3
%  C_run=4.6255;
 C_start=1; %house 9
 C_run=1;

[model_EMILP] = function_construction_EMILP(P_top, P_bottom, Q_top, Q_bottom, State_Limit , P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega,test_data_num,S,test_day_num,penlty_s,penlty_l,C_start,C_run);
% 
% 
[result] = solve(model_EMILP,0.001);
% [x,fval,exitflag,output]= cplexmiqcp(H,f,Aineq,bineq,Aeq,beq,l,Q,r,sostype,sosind,soswt,lb,ub,ctype,x0,options)
disp('Optimize done!!');
x_value=result.x;

P_value = x_value(state_size*T*2+1:state_size*T*3, :); % ȡ����������Pit��ֵ
device_state = x_value(1:state_size*T, :); % ȡ��0-1����Xit��ֵ 
  EMILP_state=[EMILP_state,reshape(device_state,state_size,T)];
  EMILP_power=[EMILP_power,reshape(device_state.*P_value,state_size,T)];
Decompose_data = {};
for  i= 1:N
    decompose = [];

    p1 = 1;
    if (i > 1)
        p1 = sum(S(:, 1:i-1))+1;
    end
    for t = 1:T
        temp_value = device_state(p1:p1+S(:,i)-1, :)' * P_value(p1:p1+S(:,i)-1, :);
        temp_state=device_state(p1:p1+S(:,i)-1, :);
        decompose = [decompose; temp_value];
        
        p1 = p1+state_size;
    end
    
    
    Decompose_data = [Decompose_data; decompose];
end
disp('Decompose done!!');


x_axis = 1:1:T; % T�����x����
predict_sum = sparse(test_data_num, 1);
figure(1)          % define figure
for i = 1:N
    predict_sum = predict_sum+Decompose_data{i};
    subplot(N+2,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
    plot(x_axis, Decompose_data{i}, x_axis, P_test{i});
    legend('predict','true');
    title(select_appliance_name{i});
end
subplot(N+2,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
plot(x_axis, sparse(T,1), x_axis, abs(P_Sum-predict_sum));
legend('predict','unknow');
title('unknow device');

subplot(N+2,1,N+2);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
plot(x_axis, predict_sum, x_axis, P_Sum);
legend('predict','true');
title('Total consumption');

[RSE_EMILP, R_square_EMILP, AC_EMILP, h_predict_EMILP, h_true_EMILP, h_error_EMILP,OCC_EMILP] = evaluation_func(P_test, Decompose_data);



end