function [NSAC] = function_NSAC(predict_path,true_list,S,always_On_appliance,N)
%FUNCTION_ �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
predict_power=readmatrix(predict_path)';
true_x=[];
for i=1:N
    [result_Idx,C,sumD,D] = kmeans(true_list{i},S(i),'dist','sqEuclidean','Replicates',4);
    cluster_Idx=result_Idx;
    C_sort=sort(C);
    for j=1:S(i)
        
        if(sum(C_sort)~=0)
            index_row=find(C==C_sort(j));
            index_cluter=find(result_Idx==index_row);
            cluster_Idx(index_cluter)=j;
        else
            cluster_Idx(1:end)=1;
        end
        
    end
    
    result_Idx=cluster_Idx;
    true_x=[true_x,result_Idx];
    
end
NSAC=[];
for i=1:N
    if(always_On_appliance(i)==0)
        if(sum(true_list{i}(find(true_x(:,i)>1)))>0)
            NSAC=[NSAC;sum(abs(true_list{i}(find(true_x(:,i)>1))-predict_power(find(true_x(:,i)>1),i)))/sum(true_list{i}(find(true_x(:,i)>1)))];
        else
            NSAC=[NSAC;0];
        end
    else
        if(sum(true_list{i}(find(true_x(:,i)>0)))>0)
            NSAC=[NSAC;sum(abs(true_list{i}(find(true_x(:,i)>0))-predict_power(find(true_x(:,i)>0),i)))/sum(true_list{i}(find(true_x(:,i)>0)))];
        else
            NSAC=[NSAC;0];
        end
    end
end

end

