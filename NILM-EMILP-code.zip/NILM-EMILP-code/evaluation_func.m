function [AC,OAC] = evaluation_func(true_list, predict_list)
N=length(true_list);
AC = calculate_AC(true_list, predict_list, N);
OAC= calculate_OAC(true_list, predict_list);
end



function [ans] = calculate_AC(true_list, predict_list, N)
ans = [];
for i = 1:N
    true_data = true_list{i};
    predict = predict_list{i};
    if(sum(true_data)~=0)
        ans = [ans; 1-sum(abs(true_data-predict))/(2*sum(true_data))];
    else
        if(sum(predict)~=0)
            ans = [ans; 1-sum(abs(true_data-predict))/(2*sum(predict))];
        else
            ans = [ans;1];
        end
    end
end
end


function  [ans] = calculate_OAC(true_list, predict_list)
true_list=cell2mat(true_list);
if(sum(true_list,'all')~=0)
    predict_list=cell2mat(predict_list');
    diff=sum(abs(true_list-predict_list),'all');
    ans=1-diff/(2*sum(true_list,'all'));
else
    predict_list=cell2mat(predict_list');
    if(sum(predict_list,'all')==0)
        ans=1;
    else
        diff=sum(abs(true_list-predict_list),'all');
        ans=1-diff/(2*sum(predict_list,'all'));
    end
end
end
