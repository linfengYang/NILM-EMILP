function [beta] = function_DRO_LR_fixB(x, y, eta, B)
%   linear regression based on distributionally robust optimization

N=size(x,2);%the number of sample

% a,b1,...,bn,beta  the number of variable
a_num=length(eta);
b_num=N;
beta_num=size(x,1);
x_num=a_num+b_num+beta_num;

% location
location_total=0;
a_location=location_total+1:location_total+a_num;
location_total=location_total+a_num;

b_location=location_total+1:location_total+b_num;
location_total=location_total+b_num;

beta_location=location_total+1:location_total+beta_num;
location_total=location_total+beta_num;
% DRO linear regression model

% min a*r+1/N*sum(b1:bn)
f=sparse(x_num,1);
f(a_location,:)=eta;
f(b_location,:)=1/N*ones(N,1);

%nonlinear constraint
%||beta||^2 _2+1<=a^2
q=sparse(x_num,x_num);
for i=1:length(a_location)
q(a_location(i),a_location(i))=-1;
end
for i=1:length(beta_location)
q(beta_location(i),beta_location(i))=1;
end
l=zeros(x_num,1);
r=-1;

%inequality
Aineq=[];
bineq=[];

row_index=1:N;
col_index=1:N;

%yi-xi*beta<=bi
Aineq=[Aineq;sparse(N,a_num),sparse(row_index,col_index,-1*ones(N,1)),-1*x'];
bineq=[bineq;-1*y];

%-1*��yi-xi*beta��<=bi
Aineq=[Aineq;sparse(N,a_num),sparse(row_index,col_index,-1*ones(N,1)),x'];
bineq=[bineq;y];

lb=sparse(x_num,1);
lb(beta_location,:)=-inf;
lb(beta_location(1),:)=B;
ub=inf*ones(x_num,1);
ub(beta_location(1))=B;
ctype='';
ctype(1:x_num)='C';

%
DRO_model.f=f;
DRO_model.Aineq=Aineq;
DRO_model.bineq=bineq;
DRO_model.Aeq=[];
DRO_model.beq=[];
DRO_model.lb=lb;
DRO_model.ub=ub;
DRO_model.ctype=ctype;
DRO_model.quadcon(1).Qc=q;
DRO_model.quadcon(1).q=l;
DRO_model.quadcon(1).rhs=r;


[result] = solve(DRO_model,0.005);
beta=result.x(beta_location);
% loss=result.objval;


end

% function [result] = solve(DRO_model)
% 
% GAP = 0.005;
% options = cplexoptimset;
% options.mip.tolerances.mipgap=GAP;
% 
% H = [];
% [result, fval, exitflag, output] = cplexmiqp(H,DRO_model.f, DRO_model.Aineq, DRO_model.bineq, DRO_model.Aeq, DRO_model.beq,[],[],[],DRO_model.lb,DRO_model.ub, DRO_model.ctype);
% % disp(result);
% % fprintf('Obj: %e\n', result.objval);
% 
% end
