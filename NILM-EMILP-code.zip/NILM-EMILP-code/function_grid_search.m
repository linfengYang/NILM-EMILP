function [C_sart,C_run]=function_grid_search(P_top, P_bottom, Q_top, Q_bottom, State_Limit , P_data, Q_data, P_up, P_down, Q_up, Q_down, Transition_model, Omega,test_data_num,S,test_day_num,validate_data_location,select_appliance_name,penlty_s,penlty_l,state_size,T,N,m1,m2,Total_iter,int_length,always_On_appliance)
P_data=P_data(validate_data_location,:);
P_Sum=sum(P_data,2);
if(~isempty(Q_data))
Q_data=Q_data(validate_data_location,:);
Q_Sum=sum(Q_data,2);
else
    Q_Sum=[];
end


G1=linspace(1,m1,int_length);
G2=linspace(1,m2,int_length);


x1_max=-1e10;
x2_max=-1e10;
f_max=-1e10;

for iter=1:Total_iter
    
    for j=1:length(G1)
        for k=1:length(G2)
            
            [model_EMILP] = function_construction_EMILP(P_top, P_bottom, Q_top, Q_bottom, State_Limit , P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega,test_data_num,S,test_day_num,penlty_s,penlty_l,G1(j),G2(k));
            
            
            [result] = solve(model_EMILP,0.001);
            % [x,fval,exitflag,output]= cplexmiqcp(H,f,Aineq,bineq,Aeq,beq,l,Q,r,sostype,sosind,soswt,lb,ub,ctype,x0,options)
            disp('Optimize done!!');
            x_value=result.x;
            EMILP_x=reshape(x_value(1:state_size*T),state_size,T);
            P_value = x_value(state_size*T*2+1:state_size*T*3, :); % 取出连续变量Pit的值
            device_state = x_value(1:state_size*T, :); % 取出0-1变量Xit的值
            
            Decompose_data = {};
            for  i= 1:N
                decompose = [];
                p1 = 1;
                if (i > 1)
                    p1 = sum(S(:, 1:i-1))+1;
                end
                for t = 1:T
                    temp_value = device_state(p1:p1+S(:,i)-1, :)' * P_value(p1:p1+S(:,i)-1, :);
                    decompose = [decompose; temp_value];
                    p1 = p1+state_size;
                end
                Decompose_data = [Decompose_data; decompose];
            end
            disp('Decompose done!!');
            
            
            x_axis = 1:1:T; % T个点的x座标
            predict_sum = sparse(test_data_num, 1);
            figure(1)          % define figure
            P_test={};
            for i = 1:N
                predict_sum = predict_sum+Decompose_data{i};
                subplot(N+2,1,i);     % subplot(x,y,n)x表示显示的行数，y表示列数，n表示第几幅图片
                plot(x_axis, Decompose_data{i}, x_axis, P_data(:,i));
                legend('predict','true');
                title(select_appliance_name{i});
                P_test{i}=P_data(:,i);
            end
            subplot(N+2,1,N+1);     % subplot(x,y,n)x表示显示的行数，y表示列数，n表示第几幅图片
            plot(x_axis, sparse(T,1), x_axis, abs(P_Sum-predict_sum));
            legend('predict','unknow');
            title('unknow device');
            
            subplot(N+2,1,N+2);     % subplot(x,y,n)x表示显示的行数，y表示列数，n表示第几幅图片
            plot(x_axis, predict_sum, x_axis, P_Sum);
            legend('predict','true');
            title('Total consumption');
            
            [RSE_EMILP, R_square_EMILP, AC_EMILP, h_predict_EMILP, h_true_EMILP, h_error_EMILP] = evaluation_func(P_test, Decompose_data,EMILP_x,S,always_On_appliance);
            mean_AC=mean(AC_EMILP);
            if mean_AC>=f_max
                iter
                max_AC=AC_EMILP;
                f_max=mean_AC
                x1_max=G1(j)
                x2_max=G2(k)
            end
        end
    end
    
G1=linspace(x1_max-x1_max/10,x1_max+x1_max/10,10);
G2=linspace(x2_max-x2_max/10,x2_max+x2_max/10,10);
    
    
end


end
