function [state_beta_new] = DRO_v2(list_old, accuracy, eta)
%     [ state_beta_old ] = function_DRO_LR( [ones(1, length(list_old)); [1:length(list_old)]], list_old, eta);
[ state_beta_old ] = regress( list_old, [ones(1, length(list_old)); [1:length(list_old)]]');
state_min = state_beta_old(1, :)+0*state_beta_old(2, :);
state_max = state_beta_old(1, :)+length(list_old)*state_beta_old(2, :);
list_new =  list_old(find(list_old>=state_min & list_old<= state_max));
[ state_beta_new ] = function_DRO_LR( [ones(1, length(list_new)); [1:length(list_new)]], list_new, eta);
rate = abs((state_beta_old(1, :)-state_beta_new(1, :))/state_beta_old(1, :));
disp('rate: '+rate);
    while (rate > accuracy)
        state_beta_old = state_beta_new;
        %         [ state_beta_old ] = function_DRO_LR( [ones(1, length(list_old)); [1:length(list_old)]], list_old, eta);
        [ state_beta_old ] = regress( list_old, [ones(1, length(list_old)); [1:length(list_old)]]');
        state_min = state_beta_old(1, :)+0*state_beta_old(2, :);
        state_max = state_beta_old(1, :)+length(list_old)*state_beta_old(2, :);
        list_new =  list_old(find(list_old>=state_min & list_old<= state_max));
%         [ state_beta_new ] = function_DRO_LR( [ones(1, length(list_new)); [1:length(list_new)]], list_new, eta);
                [ state_beta_new ] = regress( list_new, [ones(1, length(list_new)); [1:length(list_new)]]');

rate = abs((state_beta_old-state_beta_new)/state_beta_old);
    end
end
