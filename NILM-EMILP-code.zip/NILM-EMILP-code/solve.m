function [result] = solve(solve_model,tolerance_GAP,timelimit)
%SOLVE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

%GUROBI
names={};
for i=1:length(solve_model.lb)
    names(i)={strcat('x',num2str(i))};
end
model.modelname='solve_model';
if(isfield(solve_model,'Q'))
    if(~isempty(solve_model.Q))
        model.Q=solve_model.Q;
    end
end
if(isfield(solve_model,'Qc'))
    if(~isempty(solve_model.Qc))
        model.Qc=solve_model.Qc;
        model.l=solve_model.l;
        model.r=solve_model.r;
        for i=1:length(model.Qc)
            model.quadcon(i).Qc=model.Qc{i};
            model.quadcon(i).q=model.l(:,i);
            model.quadcon(i).rhs=model.r(i);
        end
    end
end

model.obj = full(solve_model.f);
model.A = [solve_model.Aineq;solve_model.Aeq];
model.rhs = full([solve_model.bineq;solve_model.beq]);
model.sense(1:size(solve_model.Aineq,1)) = '<';
model.sense(size(solve_model.Aineq,1)+1:size(solve_model.Aineq,1)+size(solve_model.Aeq,1)) = '=';
model.vtype = solve_model.ctype;
model.modelsense = 'min';
model.varnames = names;
model.lb=full(solve_model.lb);
model.ub=full(solve_model.ub);
params.outputflag = 1;
if(exist('tolerance_GAP'))
    params.MIPGap=tolerance_GAP;
else
    params.MIPGap=0.001;
end
% params.ResultFile = 'MDRO.mps';
if(exist('timelimit'))
 params.timelimit = timelimit;
end
result = gurobi(model, params);
% disp(result);
% fprintf('Obj: %e\n', result.objval);

%CPLEX
% solve_model.H=[];
% cplex_milp = Cplex('Milp for HTC');
% cplex_milp.Model.sense = 'minimize';
% cplex_milp.Model.obj = solve_model.f;
% cplex_milp.Model.lb = solve_model.lb;
% cplex_milp.Model.ub = solve_model.ub;
% cplex_milp.Model.A = [solve_model.Aineq;solve_model.Aeq];
% cplex_milp.Model.lhs = [-Inf.*ones(size(solve_model.bineq,1),1);solve_model.beq];
% cplex_milp.Model.rhs = [solve_model.bineq;solve_model.beq];
% cplex_milp.Model.ctype = solve_model.ctype;
% cplex_milp.Model.Q = solve_model.H;
% cplex_milp.Param.mip.tolerances.mipgap.Cur = 0.001;%���MIP����ݲ�����ȣ�
% cplex_milp.Param.timelimit.Cur=10000;
% cplex_milp.solve();
% F = cplex_milp.Solution.objval;
% disp(F);
% result=cplex_milp.Solution;
end

