function [model] = function_construction_EMILP(P_top, P_bottom, Q_top, Q_bottom, State_Limit , P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, C,T,S,test_day_num,penlty_s,penlty_l,C_start,C_run)
%FUNCTION_CONSTRUCTION_EMILP �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
N = length(S);% �����豸����
state_size = sum(S);

state_variable_location(:,1)=1:state_size:state_size*T;


index_appliance=[];
for i=1:N
    index_appliance=[index_appliance;i*ones(S(i),1)];
end
% ����Xit+Sit+Pit+Qit+kexiPT+kexiQT = state_szie*T*4+T*2
penalty_temp1 = C_start*C';
penalty_temp2 =sparse(1, state_size);
% for t = 2:T
%     penalty_temp2 = [penalty_temp2, penalty_temp1];
% end
penalty_temp3 = repmat(penalty_temp1, 1, T-1);
penalty_temp2 = [penalty_temp2, penalty_temp3];
% �������մ�˳������ Xit+Sit+Pit+Qit+kexiPT+kexiQT 
%penlty 1
f = [penalty_temp1, sparse(1, state_size*(T-2)), -1*penalty_temp1, 2*penalty_temp2, sparse(1, 2*state_size*T), ones(1, T), ones(1, T)];
total_var_num=length(f);
%penlty 2
penlty_s=repmat(penlty_s,1,test_day_num);
penlty_l=repmat(penlty_l,1,T);
penlty_s=(1-penlty_s).*penlty_l;
penlty_s=reshape(C_run*penlty_s,1,state_size*T);


f=f+[penlty_s,sparse(1, 3*state_size*T),sparse(1,2*T)];
H= [];
disp('object funtion Done!');
% Լ��

c2_temp1 = sparse(T, state_size*T);
p1 = 1;
for t =1:T
    c2_temp1(t, p1:p1+state_size-1) = ones(1, state_size);
    p1 = p1+state_size;
end
c2_temp2 = -1 * sparse([1:T], [1:T], ones(T,1), T, T);
c2_1 = [sparse(T, state_size*T*2), -1*c2_temp1, sparse(T, state_size*T), c2_temp2, sparse(T, T)];
b2_1 = [-1 * P_Sum];
c2_2 = [sparse(T, state_size*T*2), c2_temp1, sparse(T, state_size*T), c2_temp2, sparse(T, T)];
b2_2 = [P_Sum];

c2 = [c2_1; c2_2];
b2 = [b2_1; b2_2];
disp('c2 Done!');

if(~isempty(Q_Sum))
c3_temp1 = sparse(T, state_size*T);
p1 = 1;
for t =1:T
    c3_temp1(t, p1:p1+state_size-1) = ones(1, state_size);
    p1 = p1+state_size;
end
c3_temp2 = -1 * sparse([1:T], [1:T], ones(T,1), T, T);
c3_1 = [sparse(T, state_size*T*2), sparse(T, state_size*T), -1*c3_temp1, sparse(T, T), c3_temp2];
b3_1 = [-1 * Q_Sum];
c3_2 = [sparse(T, state_size*T*2), sparse(T, state_size*T), c3_temp1, sparse(T, T), c3_temp2];
b3_2 = [Q_Sum];

c3 = [c3_1; c3_2];
b3 = [b3_1; b3_2];
else
    c3=[];
    b3=[];
end


disp('c3 Done!');

% c4_temp1 = eye(state_size*(T-1)); % 1�ĶԽǾ���
c4_temp1 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], ones(state_size*(T-1), 1), state_size*(T-1), state_size*(T-1));
c4_temp2 = [sparse(state_size*(T-1), state_size), c4_temp1];
c4_temp3 = [-1*c4_temp1, sparse(state_size*(T-1), state_size)]; 
c4_temp4 = [sparse(state_size*(T-1), state_size), -1*c4_temp1];  %Sit
c4_temp5 = c4_temp2+ c4_temp3; %Xit
c4 = [c4_temp5, c4_temp4, sparse(state_size*(T-1), 2*state_size*T+2*T)];
b4 = sparse(state_size*(T-1), 1);

disp('c4 Done!');

c5_temp1 = sparse(state_size*T, state_size*T*4+2*T);
% c5_temp2 = [];
% for t = 1:T
%     c5_temp2 = [c5_temp2; State_Limit];
% end
c5_temp2 = repmat(State_Limit, T, 1);

% c5_temp1(:, state_size*T+1:state_size*T*2) = diag(c5_temp2); % ��ֵSit
% c5_temp1(:, state_size*T+1:state_size*T*2) = sparse([1:state_size*T], [1:state_size*T], c5_temp2, state_size*T, state_size*T);
% 
% % ��дһ��t=1��ʼ������״̬����С����ʱ�����
% c5_temp2 = sparse(state_size, state_size*T);
% for s = 1:state_size
%     for tao = 1:State_Limit(s)
%           c5_temp2(s, (tao-1)*state_size+s) = -1; % ��С����ʱ����-1��ϵ��
%     end
% end
% 
% c5_temp3 =  sparse(state_size*T, state_size*T);
% p1 = 1;
% p2 = 1;
% % ʱ������һ�Σ����������ƶ�һ��Tλ��
% for t = 1:T
%     c5_temp4 = c5_temp2(:, 1:state_size*(T+1-t));
%     c5_temp3(p1:p1+state_size-1, p2:state_size*T) = c5_temp4;
%     p1 = p1+state_size;
%     p2 = p2+state_size;
% end
% c5_temp1(:,1:state_size*T) = c5_temp3;
% max_limit = max(State_Limit);
% if(max_limit>=T)
%     max_limit=T;
% end
% c5 = c5_temp1(1:state_size*(T-max_limit-1),:); % 
% b5 = sparse(state_size*(T-max_limit-1), 1);


%min active time constraint
c5=[];

for i=1:state_size
    if(State_Limit(i)>=T)
        State_Limit(i)=T;
    end
    state_variable_part=state_variable_location+i-1;
    
    c5_xit=sparse([1:T],state_variable_part,-1*ones(T,1),T,state_size*T);
    
     sit_location_col=[];
     sit_location_row=[];
    for j=1:T
        sit_location_col=[sit_location_col,state_variable_part(max(j-State_Limit(i),0)+1:j)'];
        sit_location_row=[sit_location_row,j*ones(1,length([max(j-State_Limit(i),0)+1:j]))];
    end
    
    c5_sit=sparse(sit_location_row,sit_location_col,ones(length(sit_location_row),1),T,state_size*T);
    c5=[c5;c5_xit,c5_sit,sparse(T,2*state_size*T),sparse(T, T), sparse(T, T)];
    
end
c5_b=sparse(state_size*T,1);
disp('c5 Done!');





c7 = sparse(N*T, state_size*T*4+T*2);
c7_temp = sparse(N, state_size);
% ָ��
p1 = 1;
for i = 1:N
    c7_temp(i, p1:p1+S(:, i)-1) = 1;
    p1 = p1+S(:, i);
end
p1 = 1;
p2 = 1;
for t = 1:T
    c7(p1:p1+N-1, p2:p2+state_size-1) = c7_temp;
    p1 = p1+N;
    p2 = p2+state_size;
end
b7 = ones(N*T, 1);
disp('c7 Done!');


% c8_temp1 = diag(ones(state_size*T, 1)); % ��������ϵ������
c8_temp1 = sparse([1:state_size*T], [1:state_size*T], ones(state_size*T, 1), state_size*T, state_size*T);
% c8_1_temp1 = []; %Xitϵ��
% for t = 1:T
%     c8_1_temp1 = [c8_1_temp1; P_top];
% end
c8_1_temp1 = repmat(P_top, T, 1);
c8_1_temp1 = sparse([1:state_size*T], [1:state_size*T], c8_1_temp1, state_size*T, state_size*T);
% c8_2_temp1 = [];
% for t = 1:T
%     c8_2_temp1 = [c8_2_temp1; P_bottom];
% end
c8_2_temp1 = repmat(P_bottom, T, 1);
c8_2_temp1 = sparse([1:state_size*T], [1:state_size*T], c8_2_temp1, state_size*T, state_size*T);
c8_1 = [-1*c8_1_temp1, sparse(state_size*T, state_size*T), c8_temp1, sparse(state_size*T, state_size*T), sparse(state_size*T, T*2)];
b8_1 = sparse(state_size*T, 1);

c8_2 = [c8_2_temp1, sparse(state_size*T, state_size*T), -1*c8_temp1, sparse(state_size*T, state_size*T), sparse(state_size*T, T*2)];
b8_2 = sparse(state_size*T, 1);
c8 = [c8_1; c8_2];
b8 = [b8_1; b8_2];
disp('c8 done!!');


% c9_temp1 = diag(ones(state_size*T, 1)); % ��������ϵ������
if(~isempty(Q_top))
c9_temp1 = sparse([1:state_size*T], [1:state_size*T], ones(state_size*T, 1), state_size*T, state_size*T);

c9_1_temp1 = repmat(Q_top, T, 1);
c9_1_temp1 = sparse([1:state_size*T], [1:state_size*T], c9_1_temp1, state_size*T, state_size*T);
c9_2_temp1 = repmat(Q_bottom, T, 1);
c9_2_temp1 = sparse([1:state_size*T], [1:state_size*T], c9_2_temp1, state_size*T, state_size*T);

c9_1 = [-1*c9_1_temp1, sparse(state_size*T, state_size*T), sparse(state_size*T, state_size*T), c9_temp1, sparse(state_size*T, T*2)];
b9_1 = sparse(state_size*T, 1);
c9_2 = [c9_2_temp1, sparse(state_size*T, state_size*T), sparse(state_size*T, state_size*T), -1*c9_temp1, sparse(state_size*T, T*2)];
b9_2 = sparse(state_size*T, 1);
c9 = [c9_1; c9_2];
b9 = [b9_1; b9_2];
else
    c9=[];
    b9=[];
end
disp('c9 done!!');


% c12_temp1 = eye(state_size*(T-1));
c12_temp1 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], ones(state_size*(T-1), 1), state_size*(T-1), state_size*(T-1));
c12_temp2 = [-1*c12_temp1, sparse(state_size*(T-1), state_size)];
c12_temp3 = [sparse(state_size*(T-1), state_size), c12_temp1];

c12_temp4 = repmat(P_up, T-1, 1);
c12_temp5 = repmat(P_top, T-1, 1);
% c12_temp4 = diag(c12_temp4);
% c12_temp5 = diag(c12_temp5);
c12_temp4 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], c12_temp4, state_size*(T-1), state_size*(T-1));
c12_temp5 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], c12_temp5, state_size*(T-1), state_size*(T-1));

c12_temp4 = [sparse(state_size*(T-1), state_size), -1*c12_temp4];
c12_temp5 = [sparse(state_size*(T-1), state_size), -1*c12_temp5];
c12 = [c12_temp4, c12_temp5, c12_temp2+c12_temp3, sparse(state_size*(T-1), state_size*T), sparse(state_size*(T-1), T*2)];
b12 = sparse(state_size*(T-1), 1);
disp('c12 done!!');


P_top_sub = max(P_top - P_down,zeros(size(P_top,1),1));
c13_temp1 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], ones(state_size*(T-1), 1), state_size*(T-1), state_size*(T-1));
c13_temp2 = [c13_temp1, sparse(state_size*(T-1), state_size)];
c13_temp3 = [sparse(state_size*(T-1), state_size), -1*c13_temp1];

c13_temp4 = repmat(P_top_sub, T-1, 1);
c13_temp7 = repmat(P_top, T-1, 1);
c13_temp4 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], c13_temp4, state_size*(T-1), state_size*(T-1));
c13_temp7 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], c13_temp7, state_size*(T-1), state_size*(T-1));
% c13_temp5 = [sparse(state_size*(T-1), state_size), -1*c13_temp4]; %Sit
% c13_temp6 = [sparse(state_size*(T-1), state_size), c13_temp4];%Xit
c13_temp5 = [sparse(state_size*(T-1), state_size), c13_temp4]; %Sit
c13_temp6 = [sparse(state_size*(T-1), state_size), -1*c13_temp4];%Xit
c13_temp7 = [-1*c13_temp7, sparse(state_size*(T-1), state_size)];%Xi,t-1

c13 = [c13_temp6+c13_temp7, c13_temp5, c13_temp2+c13_temp3, sparse(state_size*(T-1), state_size*T), sparse(state_size*(T-1), T*2)];
b13 = sparse(state_size*(T-1), 1);
disp('c13 done!!');

%Q
if(~isempty(Q_up))
c14_temp1 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], ones(state_size*(T-1), 1), state_size*(T-1), state_size*(T-1)); % �ȼ� c14_temp1 = eye(state_size*(T-1));
c14_temp2 = [-1*c14_temp1, sparse(state_size*(T-1), state_size)];
c14_temp3 = [sparse(state_size*(T-1), state_size), c14_temp1];

c14_temp4 = repmat(Q_up, T-1, 1);
c14_temp5 = repmat(Q_top, T-1, 1);
% c14_temp4 = diag(c14_temp4);
% c14_temp5 = diag(c14_temp5);
c14_temp4 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], c14_temp4, state_size*(T-1), state_size*(T-1));
c14_temp5 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], c14_temp5, state_size*(T-1), state_size*(T-1));
c14_temp4 = [sparse(state_size*(T-1), state_size), -1*c14_temp4];
c14_temp5 = [sparse(state_size*(T-1), state_size), -1*c14_temp5];
c14 = [c14_temp4, c14_temp5, sparse(state_size*(T-1), state_size*T), c14_temp2+c14_temp3, sparse(state_size*(T-1), T*2)];
b14 = sparse(state_size*(T-1), 1);
disp('c14 done!!');


Q_top_sub =max(Q_top - Q_down,zeros(size(Q_top,1),1));
% c15_temp1 = eye(state_size*(T-1));
c15_temp1 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], ones(state_size*(T-1), 1), state_size*(T-1), state_size*(T-1));
c15_temp2 = [c15_temp1, sparse(state_size*(T-1), state_size)];
c15_temp3 = [sparse(state_size*(T-1), state_size), -1*c15_temp1];
% c15_temp4 = [];
% c15_temp7 = [];
% for i = 1:T-1
%     c15_temp4 = [c15_temp4; Q_top_sub];
%     c15_temp7 = [c15_temp7; Q_top];
% end
c15_temp4 =repmat(Q_top_sub, T-1, 1);
c15_temp7 = repmat(Q_top, T-1, 1);
c15_temp7 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], c15_temp7, state_size*(T-1), state_size*(T-1));
c15_temp4 = sparse([1:state_size*(T-1)], [1:state_size*(T-1)], c15_temp4, state_size*(T-1), state_size*(T-1));
% c15_temp5 = [sparse(state_size*(T-1), state_size), -1*c15_temp4]; %Sit
% c15_temp6 = [sparse(state_size*(T-1), state_size), c15_temp4];%Xit
c15_temp5 = [sparse(state_size*(T-1), state_size), c15_temp4]; %Sit
c15_temp6 = [sparse(state_size*(T-1), state_size), -1*c15_temp4];%Xit
c15_temp7 = [-1*c15_temp7, sparse(state_size*(T-1), state_size)];%Xi,t-1

c15 = [c15_temp6+c15_temp7, c15_temp5, sparse(state_size*(T-1), state_size*T), c15_temp2+c15_temp3, sparse(state_size*(T-1), T*2)];
b15 = sparse(state_size*(T-1), 1);
disp('c15 done!!');
else
    c14=[];
    b14=[];
    c15=[];
    b15=[];
end


%state transition constraint
Aineq_constraint_state_transition=[];
bineq_constraint_state_transition=[];

for i=1:N
   [row_index,col_index]=find(Transition_model{i}==0);
   if(~isempty(row_index))
       appliance_index=find(index_appliance==i);
       state_location_col=[appliance_index(row_index):state_size:state_size*(T-1)];
       constraint_state_transition=sparse([1:T-1],state_location_col,ones(1,T-1),T-1,total_var_num);
       
       state_location_col=[appliance_index(col_index)+state_size:state_size:state_size*T];
       constraint_state_transition=constraint_state_transition+sparse([1:T-1],state_location_col,ones(1,T-1),T-1,total_var_num);
       Aineq_constraint_state_transition=[Aineq_constraint_state_transition;constraint_state_transition];
       bineq_constraint_state_transition=[bineq_constraint_state_transition;ones(T-1,1)];
   end
end



Aineq = [c2; c4; c5; c8; c9;c12; c13;c14; c15;Aineq_constraint_state_transition];%  
bineq = [b2; b4; c5_b; b8; b9;b12; b13;b14; b15;bineq_constraint_state_transition];%  
% Aineq = [c2; c4; c5; c8; c9];
% bineq = [b2; b4; b5; b8; b9];

% �������
% Aineq = [c2; c4; c5; c8];
% bineq = [b2; b4; b5; b8];



% ��ʽԼ��
Aeq = [c7];
beq = [b7];
disp('build model done!!!');

ctype = '';
ctype(1:state_size*T*2) = 'B';
ctype(state_size*T*2+1:(state_size*T*4+T*2)) = 'C';
lb = sparse(state_size*T*4+T*2, 1);
ub = [ones(state_size*T*2, 1);inf*ones(state_size*T*2+T*2,1)];

model.H=H;
model.f = f;
model.Aineq = Aineq;
model.bineq = bineq;
model.Aeq = Aeq;
model.beq = beq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;

end

