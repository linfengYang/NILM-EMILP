%AMPDS:{ 'RSE',	'GRE',	'MHE',	'B1E'	,'BME'	,'CWE',	'DWE','EQE','FRE',	'HPE',	'OFE',	'UTE',	'WOE',	'B2E',	'CDE',	'DNE',	'EBE',	'FGE',	'HTE',	'OUE',	'TVE',	'UNE'}
%AMPDS_alwaysOn:[1,0,1,0,0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0,1,1]
%AMPDS_Appliance_State_num=[3,3,3,3,2,3,2,3,3,2,4,3,2,2,2,3,0,3,3,3,2,5];
clear all;
data_Folder_Path='data\';
data_Set={'AMPDS'};
data_type={'active power','reactive power'};

select_data_Set={'AMPDS'};
select_data_type={'P','Q'};% P is active power  Q is reactive power
select_appliance_name={'CDE','FRE','DWE','HPE' ,'BME','TVE','CWE'}; %,'OFE' 20��û�п���,,

%{'CDE', 'FRE', 'DWE', 'HPE'};

AMPDS_S=[3,3,3,3,3,2,3,2,3,2,2,4,2,2,2,2,3,0,3,3,3,2,5];
AMPDS_alwaysOn=[1,1,0,1,0,0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0,1,1];
EMILP_result=[];
NSAC=[];
train_day_num=20;
test_day_num=1;
train_data_num=60*24*train_day_num;
TIME=10000;
partition_num=1;
partition_index=1;
snr=0;
% for snr=35:-5:10
    for partition_index=1:7
        result_path=strcat('result/AMPDS/result_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_snr',num2str(snr),'.txt');
        
        test_data_num=60*24*(test_day_num/partition_num);
        train_data_start_location = 1; % ѵ������������ʼ��
        test_data_start_location = (train_data_num+test_data_num*(partition_index-1)+1)*ones(length(select_appliance_name),1);%[31200; 4500; 5700; 14000];
        
        
        [Total_data,train_data,test_data,appliance_location] = function_read_data(data_Folder_Path,select_data_Set,select_data_type,select_appliance_name,...
            train_data_num,test_data_num,train_data_start_location,test_data_start_location);
        
        %add noise
        % for i=1:size(train_data.AMPDS.appliance_P,2)
        %     train_data_noise.AMPDS.appliance_P(:,i) = awgn(train_data.AMPDS.appliance_P(:,i),snr,'measured');
        %     train_data_noise.AMPDS.appliance_Q(:,i) = awgn(train_data.AMPDS.appliance_Q(:,i),snr,'measured');
        %     train_data_noise.AMPDS.appliance_P(train_data_noise.AMPDS.appliance_P<0)=0;
        %     train_data_noise.AMPDS.appliance_Q(train_data_noise.AMPDS.appliance_Q<0)=0;
        % end
        
        
        S=AMPDS_S(appliance_location);
        always_On_appliance=AMPDS_alwaysOn(appliance_location);
        
        cluster_id=[];
        for i=1:length(select_appliance_name)
            eval(strcat('input_data=','[[1:size(train_data.',select_data_Set{1},'.appliance_',select_data_type{1},',1)]'',','train_data.',select_data_Set{1},'.appliance_',select_data_type{1},'(:,i)];'));
            [result_Idx]=function_getStateNumByKmean(input_data(:,2),select_appliance_name{i},-1,S(i)); %%if want to use elbow rule ,change '-1' to 'i'
            cluster_id=[cluster_id,result_Idx];
        end
        
        N = length(S); % �����豸����
        state_size = sum(S);
        T=test_data_num;
        %% EMILP
        
        [P, P_top, P_bottom, Q, Q_top, Q_bottom, State_Limit, P_test, Q_test, P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega, P_train,penlty_s,penlty_l,State_max_Limit] = DataProcessing_EMILP(train_data,test_data,select_appliance_name,select_data_type,select_data_Set,S,cluster_id,train_data_num,test_data_num,train_day_num,always_On_appliance);
        P_test=num2cell(test_data.AMPDS.appliance_P,1);
        disp('data processing Done!');
        C_start=0.892;
        C_run=1.0419;
        % validate_day_num=6;
        % validate_data_num=60*24*validate_day_num;
        % validate_data_num=60*24*1;
        % validate_data_location=60*24*(train_day_num-validate_day_num)+1:60*24*(train_day_num-validate_day_num+1);%60*24*train_day_num;
        % [C_sart,C_run]=function_grid_search(P_top, P_bottom, Q_top, Q_bottom, State_Limit , train_data.AMPDS.appliance_P, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega,validate_data_num,S,1,validate_data_location,select_appliance_name,penlty_s,penlty_l,state_size,validate_data_num,N,10,10,10,10,always_On_appliance);
        
        [model_EMILP] = function_construction_EMILP(P_top, P_bottom, Q_top, Q_bottom, State_Limit , P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega,test_data_num,S,test_day_num,penlty_s,penlty_l,C_start,C_run);
        
        
        [result] = solve(model_EMILP,0.001,TIME);
        % [x,fval,exitflag,output]= cplexmiqcp(H,f,Aineq,bineq,Aeq,beq,l,Q,r,sostype,sosind,soswt,lb,ub,ctype,x0,options)
        disp('Optimize done!!');
        x_value=result.x;
        
        EMILP_x=reshape(x_value(1:state_size*T),state_size,T);
        P_value = x_value(state_size*T*2+1:state_size*T*3, :); % ȡ����������Pit��ֵ
        device_state = x_value(1:state_size*T, :); % ȡ��0-1����Xit��ֵ
        
        Decompose_data = {};
        for  i= 1:N
            decompose = [];
            p1 = 1;
            if (i > 1)
                p1 = sum(S(:, 1:i-1))+1;
            end
            for t = 1:T
                temp_value = device_state(p1:p1+S(:,i)-1, :)' * P_value(p1:p1+S(:,i)-1, :);
                decompose = [decompose; temp_value];
                p1 = p1+state_size;
            end
            Decompose_data = [Decompose_data; decompose];
        end
        disp('Decompose done!!');
        
        
        x_axis = 1:1:T; % T�����x����
        predict_sum = sparse(test_data_num, 1);
        figure(1)          % define figure
        for i = 1:N
            predict_sum = predict_sum+Decompose_data{i};
            subplot(N+2,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
            plot(x_axis, Decompose_data{i}, x_axis, P_test{i});
            legend('predict','true');
            title(select_appliance_name{i});
        end
        subplot(N+2,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
        plot(x_axis, sparse(T,1), x_axis, abs(P_Sum-predict_sum));
        legend('predict','unknow');
        title('unknow device');
        
        subplot(N+2,1,N+2);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
        plot(x_axis, predict_sum, x_axis, P_Sum);
        legend('predict','true');
        title('Total consumption');
        
        EMILP_Power=Decompose_data;
        [AC_EMILP,OAC_EMILP] = evaluation_func(P_test, Decompose_data);
        model_EMILP=[];
        
        EMILP_result=[EMILP_result;AC_EMILP,[OAC_EMILP;sparse(size(AC_EMILP,1)-1,size(OAC_EMILP,2))],[result.runtime;sparse(size(AC_EMILP,1)-1,1)]];
        
    end
%     EMILP_result=[EMILP_result;sparse(1,size(EMILP_result,2))];
% end
